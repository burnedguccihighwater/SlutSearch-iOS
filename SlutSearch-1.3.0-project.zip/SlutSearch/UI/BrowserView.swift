import SwiftUI
import WebKit

private struct EmbeddedWebView: UIViewRepresentable {
    let session: BrowserSession
    func makeUIView(context: Context) -> WKWebView { session.webView }
    func updateUIView(_ uiView: WKWebView, context: Context) {}
}

/// Website-first screen: no duplicated playlists/collections/downloads tabs.
struct BrowserView: View {
    @EnvironmentObject private var browser: BrowserSession
    @EnvironmentObject private var downloads: VideoDownloadManager
    @State private var showingSearch = false
    @State private var showingQueue = false
    @State private var showingSelection = false
    @State private var showingSettings = false
    @State private var scanning = false
    @State private var scan: SiteMediaScan = .empty
    @State private var selected: Set<String> = []

    private var activeCount: Int {
        downloads.items.filter { [.queued, .downloading, .saving].contains($0.status) }.count
    }

    var body: some View {
        VStack(spacing: 0) {
            HStack(spacing: 6) {
                Text("SlutSearch <3")
                    .font(.system(size: 15, weight: .semibold))
                    .lineLimit(1).minimumScaleFactor(0.8)
                Spacer(minLength: 0)
                control("chevron.left", "Назад", disabled: !browser.canGoBack) { browser.back() }
                control("house", "Домой") { browser.home() }
                control("magnifyingglass", "Улучшенный поиск") { showingSearch = true }
                if activeCount > 0 {
                    Button { showingQueue = true } label: {
                        HStack(spacing: 3) {
                            Image(systemName: "arrow.down.circle.fill")
                            Text("\(activeCount)").font(.caption2.bold())
                        }
                        .frame(minWidth: 42, minHeight: 40)
                    }
                    .accessibilityLabel("Загрузки: \(activeCount)")
                }
                control("ellipsis", "Настройки") { showingSettings = true }
            }
            .tint(.white)
            .padding(.horizontal, 12)
            .frame(minHeight: 46)
            .background(Color(red: 0.045, green: 0.075, blue: 0.105))

            EmbeddedWebView(session: browser)
                .frame(maxWidth: .infinity, maxHeight: .infinity)

            // This row belongs to the current *site* page, not a parallel application menu.
            if browser.pageKind != .other {
                HStack(spacing: 12) {
                    Label(browser.pageKind == .playlist ? "Плейлист сайта" : "Публикация", systemImage: browser.pageKind == .playlist ? "rectangle.stack" : "photo")
                        .font(.caption).foregroundColor(.secondary)
                    Spacer(minLength: 3)
                    Button {
                        discoverPageFiles()
                    } label: {
                        if scanning { ProgressView().tint(.white) }
                        else { Label("Скачать", systemImage: "arrow.down.to.line") }
                    }
                    .disabled(scanning)
                    .font(.system(size: 14, weight: .semibold))
                    .buttonStyle(.borderedProminent)
                    .tint(Color(red: 0.12, green: 0.48, blue: 0.85))
                }
                .padding(.horizontal, 13)
                .padding(.vertical, 7)
                .background(Color(red: 0.045, green: 0.075, blue: 0.105))
            }
        }
        .sheet(isPresented: $showingSearch) {
            NavigationView {
                SearchView(onSearch: { showingSearch = false })
                    .navigationTitle("Поиск по тегам")
                    .navigationBarTitleDisplayMode(.inline)
                    .toolbar { ToolbarItem(placement: .navigationBarTrailing) { Button("Готово") { showingSearch = false } } }
            }
            .preferredColorScheme(.dark)
        }
        .sheet(isPresented: $showingQueue) {
            NavigationView {
                DownloadsView()
                    .navigationTitle("Загрузки")
                    .navigationBarTitleDisplayMode(.inline)
                    .toolbar { ToolbarItem(placement: .navigationBarTrailing) { Button("Готово") { showingQueue = false } } }
            }
            .preferredColorScheme(.dark)
        }
        .sheet(isPresented: $showingSelection) {
            NavigationView {
                mediaSelection
                    .navigationTitle("Сохранить в Фото")
                    .navigationBarTitleDisplayMode(.inline)
                    .toolbar { ToolbarItem(placement: .navigationBarTrailing) { Button("Закрыть") { showingSelection = false } } }
            }
            .preferredColorScheme(.dark)
        }
        .sheet(isPresented: $showingSettings) {
            NavigationView {
                Form {
                    Toggle("Скрывать навязчивые live-чаты", isOn: Binding(
                        get: { browser.blockLiveChat },
                        set: { browser.setLiveChatBlocking($0) }
                    ))
                    Button("Обновить сайт") { browser.refresh(); showingSettings = false }
                    Button("История загрузок") { showingSettings = false; showingQueue = true }
                }
                .navigationTitle("Настройки SlutSearch")
                .toolbar { ToolbarItem(placement: .navigationBarTrailing) { Button("Готово") { showingSettings = false } } }
            }
            .preferredColorScheme(.dark)
        }
        .onAppear {
            // Downloads initiated by the website itself are handed to the same Photos pipeline.
            browser.onWebsiteFileDownloaded = { fileURL, sourceURL in downloads.saveWebsiteFile(fileURL, sourceURL: sourceURL) }
        }
    }

    private func control(_ symbol: String, _ label: String, disabled: Bool = false, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Image(systemName: symbol)
                .frame(width: 36, height: 40)
                .contentShape(Rectangle())
        }
        .disabled(disabled)
        .accessibilityLabel(label)
    }

    private func discoverPageFiles() {
        scanning = true
        browser.scanSiteMedia { result in
            DispatchQueue.main.async {
                scanning = false
                scan = result
                selected = Set(result.files.map(\.id))
                if result.files.isEmpty {
                    browser.notice = "На открытой странице нет доступных прямых медиафайлов. Это не означает, что плейлист пуст: сайт может хранить оригиналы отдельно."
                } else {
                    showingSelection = true
                }
            }
        }
    }

    private var mediaSelection: some View {
        VStack(spacing: 0) {
            VStack(alignment: .leading, spacing: 5) {
                Text("Найдено файлов: \(scan.files.count)").font(.headline)
                if scan.selectedCount > 0 {
                    Text("Сайт отмечает \(scan.selectedCount) публикаций. Показываем ссылки, которые удалось определить из открытой страницы.")
                        .font(.caption).foregroundColor(.secondary)
                }
                Text("Только файлы, открытые на текущей странице. На других страницах плейлиста могут быть дополнительные публикации.")
                    .font(.caption).foregroundColor(.secondary)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(15)
            HStack {
                Button("Выбрать всё") { selected = Set(scan.files.map(\.id)) }
                Spacer()
                Button("Снять выбор") { selected.removeAll() }
            }
            .font(.caption).padding(.horizontal, 15)
            List(scan.files) { media in
                Button {
                    if selected.contains(media.id) { selected.remove(media.id) }
                    else { selected.insert(media.id) }
                } label: {
                    HStack(spacing: 12) {
                        Image(systemName: selected.contains(media.id) ? "checkmark.circle.fill" : "circle")
                            .foregroundColor(Color(red: 0.22, green: 0.60, blue: 0.99))
                        Image(systemName: media.kind == "video" ? "film" : "photo")
                        Text(media.title).lineLimit(2).font(.subheadline)
                        Spacer(minLength: 0)
                    }
                }.buttonStyle(.plain)
            }
            Button {
                let urls = scan.files.filter { selected.contains($0.id) }.map(\.url)
                guard !urls.isEmpty else { return }
                browser.downloadCookies { cookies in
                    DispatchQueue.main.async {
                        downloads.addBatch(urls, cookies: cookies)
                        showingSelection = false
                        showingQueue = true
                    }
                }
            } label: {
                Label("Скачать выбранные (\(selected.count))", systemImage: "arrow.down.to.line")
                    .frame(maxWidth: .infinity, minHeight: 44)
            }
            .buttonStyle(.borderedProminent)
            .tint(Color(red: 0.12, green: 0.48, blue: 0.85))
            .disabled(selected.isEmpty)
            .padding(15)
        }
    }
}
