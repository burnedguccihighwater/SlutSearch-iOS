import SwiftUI

struct DownloadsView: View {
    @EnvironmentObject private var manager: VideoDownloadManager

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                VStack(alignment: .leading, spacing: 5) {
                    Text("Загрузки сайта").font(.title2.bold())
                    Text("Файлы с открытых страниц сайта · сохранение в Фото iPhone")
                        .font(.caption).foregroundColor(.secondary)
                    Text("Ожидают: \(manager.items.filter { $0.status == .queued }.count) · В работе: \(manager.items.filter { $0.status == .downloading }.count) · Сохранено: \(manager.items.filter { $0.status == .completed }.count)")
                        .font(.caption2).foregroundColor(.secondary)
                }
                if manager.items.contains(where: { [.completed, .cancelled, .failed].contains($0.status) }) {
                    HStack {
                        Spacer()
                        Button("Очистить завершённые") { manager.clearFinished() }
                            .font(.caption)
                    }
                }
                ForEach(manager.items) { item in
                    VStack(alignment: .leading, spacing: 9) {
                        Text(item.title).font(.subheadline.bold()).lineLimit(2)
                        Text(item.status.rawValue).font(.caption).foregroundColor(.secondary)
                        if item.status == .downloading {
                            ProgressView(value: item.progress)
                                .tint(.purple)
                            Text("\(Int(item.progress * 100))%")
                                .font(.caption2).monospacedDigit().foregroundColor(.secondary)
                        }
                        if let error = item.error {
                            Text(error).font(.caption).foregroundColor(.orange)
                        }
                        HStack {
                            if [.queued, .downloading].contains(item.status) {
                                Button("Отменить", role: .destructive) { manager.cancel(item.id) }
                            } else if [.failed, .cancelled].contains(item.status) {
                                Button("Повторить") { manager.retry(item.id) }
                            }
                            Spacer(minLength: 8)
                            if item.status == .completed {
                                Label("Готово", systemImage: "checkmark.circle.fill")
                                    .foregroundColor(.green)
                            }
                        }.font(.caption)
                    }
                    .padding(13)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(Color(red: 0.14, green: 0.11, blue: 0.20))
                    .clipShape(RoundedRectangle(cornerRadius: 12))
                }
                if manager.items.isEmpty {
                    VStack(spacing: 10) {
                        Image(systemName: "arrow.down.to.line").font(.largeTitle).foregroundColor(.gray)
                        Text("Очередь пуста").foregroundColor(.gray)
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.top, 45)
                }
                Text("Поддерживаются прямые HTTPS-файлы JPG/PNG/HEIC/MP4/MOV/M4V. HLS, blob: и DRM не поддерживаются. При закрытии приложения незавершённые задания потребуют повтора. История загруженных файлов сохраняется, но сами файлы остаются в Фото.")
                    .font(.footnote).foregroundColor(.secondary)
            }.padding(16)
        }
    }
}
