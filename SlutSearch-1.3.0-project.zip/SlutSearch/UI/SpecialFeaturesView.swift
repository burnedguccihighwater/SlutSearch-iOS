import SwiftUI

/// Batch operation is explicitly limited to direct downloadable URLs exposed by the loaded page.
/// It cannot enumerate hidden/paginated playlist entries, blob:, HLS, or DRM streams.
struct SpecialFeaturesView: View {
    @EnvironmentObject private var browser: BrowserSession
    @EnvironmentObject private var downloads: VideoDownloadManager
    @Environment(\.dismiss) private var dismiss
    @State private var candidates: [URL] = []
    @State private var scanning = false
    @State private var scanned = false
    @State private var truncated = false
    @State private var showingConfirm = false

    var body: some View {
        NavigationView {
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    VStack(alignment: .leading, spacing: 9) {
                        Label("Просмотр без трансляций", systemImage: "rectangle.on.rectangle.slash")
                            .font(.title3.bold())
                        Toggle(isOn: Binding(
                            get: { browser.blockLiveChat },
                            set: { browser.setLiveChatBlocking($0) }
                        )) {
                            VStack(alignment: .leading, spacing: 3) {
                                Text("Скрывать трансляции и чат")
                                Text("Запрещает всплывающие окна и скрывает навязчивые live-чаты. Обычные видео остаются доступными.")
                                    .font(.caption).foregroundColor(.secondary)
                            }
                        }
                        .tint(.purple)
                        Text("Включено по умолчанию. После переключения веб-страница обновится.")
                            .font(.caption).foregroundColor(.secondary)
                    }
                    .padding(14)
                    .background(Color.white.opacity(0.06))
                    .clipShape(RoundedRectangle(cornerRadius: 14))
                    Divider()
                    Label("Скачать весь плейлист", systemImage: "list.bullet")
                        .font(.title3.bold())
                    Text("Проверим текущую страницу на прямые видеофайлы. Для плейлистов с подгрузкой или постраничным просмотром это может быть только часть записей.")
                        .font(.footnote).foregroundColor(.secondary)
                    Button(action: scan) {
                        HStack {
                            if scanning { ProgressView().tint(.white) }
                            Label("Найти доступные видео", systemImage: "magnifyingglass")
                                .frame(maxWidth: .infinity, minHeight: 44)
                        }
                    }.buttonStyle(.borderedProminent).tint(.purple).disabled(scanning)
                    if scanned {
                        VStack(alignment: .leading, spacing: 9) {
                            Text("Обнаружено прямых видео: \(candidates.count)")
                                .font(.headline)
                            if truncated {
                                Label("Показаны только первые 100 ссылок.", systemImage: "exclamationmark.triangle")
                                    .font(.footnote).foregroundColor(.orange)
                            }
                            if candidates.isEmpty {
                                Text("В загруженном HTML не обнаружены прямые MP4/MOV/M4V. Это не означает, что видео на странице отсутствуют.")
                                    .font(.footnote).foregroundColor(.secondary)
                            } else {
                                ForEach(Array(candidates.prefix(12)), id: \.absoluteString) { url in
                                    Text(url.lastPathComponent)
                                        .font(.caption).lineLimit(1).truncationMode(.middle)
                                }
                                if candidates.count > 12 {
                                    Text("И ещё \(candidates.count - 12)…")
                                        .font(.caption).foregroundColor(.secondary)
                                }
                                Button {
                                    showingConfirm = true
                                } label: {
                                    Label("Добавить \(candidates.count) в очередь", systemImage: "arrow.down.circle")
                                        .frame(maxWidth: .infinity, minHeight: 44)
                                }.buttonStyle(.borderedProminent).tint(.purple)
                            }
                        }
                        .padding(14)
                        .background(Color.white.opacity(0.06))
                        .clipShape(RoundedRectangle(cornerRadius: 14))
                    }
                    Text("Сохраняются только непосредственно доступные файлы, на загрузку которых у тебя есть право. Никаких способов обхода защиты сайта приложение не использует.")
                        .font(.caption).foregroundColor(.secondary)
                }.padding(18)
            }
            .navigationTitle("Особые возможности")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .navigationBarTrailing) { Button("Готово") { dismiss() } } }
            .confirmationDialog("Добавить \(candidates.count) видео в очередь?", isPresented: $showingConfirm) {
                Button("Добавить в загрузки") {
                    browser.downloadCookies { cookies in
                        DispatchQueue.main.async {
                            downloads.addBatch(candidates, cookies: cookies)
                            dismiss()
                        }
                    }
                }
            } message: {
                Text("Загрузки сохраняются в Фото. Если сервер ограничит доступ, отдельные файлы могут завершиться ошибкой.")
            }
        }
        .preferredColorScheme(.dark)
    }

    private func scan() {
        scanning = true
        scanned = false
        browser.discoverDirectVideos { result in
            DispatchQueue.main.async {
                candidates = result.urls
                truncated = result.truncated
                scanning = false
                scanned = true
            }
        }
    }
}
