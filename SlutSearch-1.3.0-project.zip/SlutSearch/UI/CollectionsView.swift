import SwiftUI

struct CollectionsView: View {
    @EnvironmentObject private var store: CollectionsStore
    @EnvironmentObject private var browser: BrowserSession
    @State private var newCollectionName = ""
    var onOpenLink: () -> Void

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                Text("Мои коллекции").font(.title2.bold())
                Text("Здесь сохраняются ссылки и названия. Для офлайн-просмотра файлы нужно загрузить отдельно.")
                    .font(.footnote).foregroundColor(.secondary)
                HStack(spacing: 8) {
                    TextField("Название новой коллекции", text: $newCollectionName)
                        .textFieldStyle(.roundedBorder)
                        .submitLabel(.done)
                    Button {
                        if store.create(newCollectionName) != nil {
                            newCollectionName = ""
                        }
                    } label: { Label("Создать", systemImage: "plus") }
                        .buttonStyle(.borderedProminent).tint(.purple)
                        .disabled(newCollectionName.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                }
                ForEach(store.collections) { collection in
                    VStack(alignment: .leading, spacing: 10) {
                        HStack {
                            Image(systemName: "folder.fill").foregroundColor(.purple)
                            Text(collection.name).font(.headline).lineLimit(1)
                            Spacer()
                            Text("\(collection.links.count)").font(.caption).foregroundColor(.gray)
                            if store.collections.count > 1 && collection.id != store.collections.first?.id {
                                Button(role: .destructive) { store.deleteCollection(collection.id) } label: {
                                    Image(systemName: "trash")
                                }.accessibilityLabel("Удалить коллекцию \(collection.name)")
                            }
                        }
                        if collection.links.isEmpty {
                            Text("Пока пусто — сохраняй страницы кнопкой закладки в Обзоре.")
                                .font(.footnote).foregroundColor(.secondary)
                        }
                        ForEach(collection.links) { link in
                            HStack(spacing: 10) {
                                Button {
                                    browser.navigate(to: link.url)
                                    onOpenLink()
                                } label: {
                                    VStack(alignment: .leading, spacing: 3) {
                                        Text(link.title).font(.subheadline).lineLimit(2)
                                        Text(link.url.host ?? link.url.absoluteString)
                                            .font(.caption2).foregroundColor(.gray).lineLimit(1)
                                    }
                                    .frame(maxWidth: .infinity, alignment: .leading)
                                }.buttonStyle(.plain)
                                Button(role: .destructive) { store.remove(link.id, from: collection.id) } label: {
                                    Image(systemName: "xmark.circle")
                                }.accessibilityLabel("Убрать ссылку \(link.title)")
                            }
                            .padding(.vertical, 5)
                        }
                    }
                    .padding(14)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(Color(red: 0.13, green: 0.10, blue: 0.19))
                    .clipShape(RoundedRectangle(cornerRadius: 14))
                }
            }.padding(16)
        }
    }
}
