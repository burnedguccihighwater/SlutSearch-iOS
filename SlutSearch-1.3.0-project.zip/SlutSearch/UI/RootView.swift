import SwiftUI

/// Website-first: only the actual site owns playlists, search results, and media navigation.
/// SlutSearch adds contextual downloads instead of a second tab bar.
struct RootView: View {
    @EnvironmentObject private var browser: BrowserSession
    @EnvironmentObject private var downloads: VideoDownloadManager
    @Environment(\.scenePhase) private var scenePhase

    var body: some View {
        ZStack {
            Color(red: 0.035, green: 0.045, blue: 0.065).ignoresSafeArea()
            BrowserView()
        }
        .overlay {
            if scenePhase != .active {
                Color(red: 0.035, green: 0.045, blue: 0.065)
                    .ignoresSafeArea()
                    .overlay(Image(systemName: "eye.slash.fill").font(.largeTitle).foregroundColor(.gray))
                    .accessibilityLabel("Предпросмотр скрыт")
            }
        }
        .alert("SlutSearch", isPresented: Binding(
            get: { browser.notice != nil || downloads.notice != nil },
            set: { if !$0 { browser.notice = nil; downloads.notice = nil } }
        )) {
            Button("Понятно", role: .cancel) { browser.notice = nil; downloads.notice = nil }
        } message: {
            Text(browser.notice ?? downloads.notice ?? "")
        }
    }
}
