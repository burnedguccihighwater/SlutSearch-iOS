import SwiftUI

struct SearchView: View {
    @EnvironmentObject private var browser: BrowserSession
    @EnvironmentObject private var store: SearchStore
    var onSearch: () -> Void

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 18) {
                VStack(alignment: .leading, spacing: 5) {
                    Text("Улучшенный поиск").font(.title2.bold())
                    Text("Теги через пробел · без ограничения длины поля")
                        .font(.caption).foregroundColor(.gray)
                }
                VStack(alignment: .leading, spacing: 8) {
                    Text("Теги").font(.headline)
                    TextEditor(text: $store.query)
                        .frame(height: 100)
                        .padding(8)
                        .background(Color(red: 0.14, green: 0.12, blue: 0.20))
                        .clipShape(RoundedRectangle(cornerRadius: 12))
                        .accessibilityLabel("Теги через пробел")
                }
                Picker("Тип медиа", selection: $store.mediaKind) {
                    ForEach(MediaKind.allCases) { kind in Text(kind.rawValue).tag(kind) }
                }
                .pickerStyle(.segmented)

                Button(action: search) {
                    Label("Искать", systemImage: "magnifyingglass")
                        .frame(maxWidth: .infinity, minHeight: 40)
                }
                .buttonStyle(.borderedProminent)
                .tint(.purple)
                .disabled(SearchStore.normalize(store.query).isEmpty)

                VStack(alignment: .leading, spacing: 10) {
                    Text("Поисковые профили").font(.headline)
                    HStack(spacing: 8) {
                        TextField("Название профиля", text: $store.profileName)
                            .textFieldStyle(.roundedBorder)
                        Button("Сохранить") { store.saveProfile() }
                            .buttonStyle(.bordered)
                    }
                    ForEach(store.profiles) { profile in
                        HStack(spacing: 10) {
                            Button { store.use(profile) } label: {
                                VStack(alignment: .leading, spacing: 2) {
                                    Text(profile.name).fontWeight(.medium)
                                    Text(profile.query).font(.caption).lineLimit(1).foregroundColor(.gray)
                                }.frame(maxWidth: .infinity, alignment: .leading)
                            }
                            .buttonStyle(.plain)
                            Button(role: .destructive) { store.delete(profile) } label: {
                                Image(systemName: "trash")
                            }.accessibilityLabel("Удалить профиль \(profile.name)")
                        }
                        .padding(10)
                        .background(Color.white.opacity(0.05))
                        .clipShape(RoundedRectangle(cornerRadius: 10))
                    }
                }
                VStack(alignment: .leading, spacing: 10) {
                    HStack {
                        Text("История поиска").font(.headline)
                        Spacer()
                        if !store.history.isEmpty {
                            Button("Очистить") { store.clearHistory() }.font(.caption)
                        }
                    }
                    ForEach(store.history, id: \.self) { query in
                        Button { store.query = query } label: {
                            Text(query).font(.subheadline).lineLimit(2)
                                .frame(maxWidth: .infinity, alignment: .leading)
                        }.buttonStyle(.plain)
                            .padding(10).background(Color.white.opacity(0.05))
                            .clipShape(RoundedRectangle(cornerRadius: 10))
                    }
                }
            }
            .padding(18)
        }
    }

    private func search() {
        guard let normalized = store.recordSearch(),
              let url = SearchStore.searchURL(for: normalized, origin: browser.homeURL) else { return }
        browser.navigate(to: url, filter: store.mediaKind, searchQuery: normalized)
        onSearch()
    }
}
