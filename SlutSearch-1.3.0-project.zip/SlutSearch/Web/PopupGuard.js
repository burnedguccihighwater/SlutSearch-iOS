/* SlutSearch: suppress intrusive popup livestream/chat widgets only.
   Does not hide ordinary video players, result cards, or comments.
   Loaded at document start in each frame while protection is enabled. */
(() => {
  'use strict';
  if (window.__slutSearchPopupGuard) return;
  window.__slutSearchPopupGuard = true;

  // Do not globally disable window.open: account actions and playlist cards
  // may legitimately open a site tab. Route same-origin calls into this tab;
  // the native WKUIDelegate handles user-tapped target=_blank links.
  const originalOpen = window.open.bind(window);
  window.open = function(url, target, features) {
    if (typeof url === 'string' && url) {
      try {
        const destination = new URL(url, location.href);
        if (fromCamProvider(destination.href)) return null;
        if (destination.origin === location.origin) {
          location.assign(destination.href);
          return null;
        }
      } catch (_) {}
    }
    return originalOpen(url, target, features);
  };

  const camHosts = [
    'chaturbate.com', 'stripchat.com', 'livejasmin.com',
    'bongacams.com', 'myfreecams.com', 'camsoda.com',
    'streamate.com', 'chatango.com', 'tawk.to',
    'crisp.chat', 'tidiochat.com'
  ];
  const selectors = [
    'iframe[src]',
    '[id*="live-chat" i]', '[class*="live-chat" i]',
    '[id*="livechat" i]', '[class*="livechat" i]',
    '[id*="livestream" i]', '[class*="livestream" i]',
    '[id*="live-stream" i]', '[class*="live-stream" i]',
    '[id*="chat-widget" i]', '[class*="chat-widget" i]',
    '[id*="cam-popup" i]', '[class*="cam-popup" i]',
    '[role="dialog"]', '[class*="popup" i]', '[id*="popup" i]'
  ].join(',');
  const overlaySelector = '[role="dialog"], [class*="popup" i], [id*="popup" i], [class*="overlay" i], [id*="overlay" i]';

  function fromCamProvider(raw) {
    if (!raw) return false;
    try {
      const host = new URL(raw, location.href).hostname.toLowerCase();
      return camHosts.some(domain => host === domain || host.endsWith('.' + domain));
    } catch (_) {
      return false;
    }
  }
  function isOverlay(node) {
    const style = getComputedStyle(node);
    if (!['fixed', 'absolute', 'sticky'].includes(style.position)) return false;
    const bounds = node.getBoundingClientRect();
    return bounds.width >= 100 && bounds.height >= 90;
  }
  function hide(node) {
    if (!node || node.dataset?.slutSearchBlocked === 'true') return;
    node.dataset.slutSearchBlocked = 'true';
    node.style.setProperty('display', 'none', 'important');
    node.querySelectorAll('video').forEach(video => { try { video.pause(); } catch (_) {} });
  }
  function namedAsStreamChat(node) {
    const name = [node.id, typeof node.className === 'string' ? node.className : '', node.getAttribute('aria-label') || '']
      .join(' ').toLowerCase();
    return /live[-_ ]?chat|live[-_ ]?stream|livestream|chat[-_ ]?widget|cam[-_ ]?popup/.test(name);
  }
  function visiblyStreamAndChat(node) {
    if (!isOverlay(node) || !node.querySelector('iframe,video')) return false;
    const text = (node.textContent || '').slice(0, 1600).toLowerCase();
    const live = /\blive\b|\bstream(?:ing)?\b|трансляц|прямой эфир|стрим/.test(text);
    const chat = /\bchat\b|чат/.test(text);
    return live && chat;
  }
  function scan() {
    if (!document.documentElement) return;
    const nodes = document.querySelectorAll(selectors);
    for (const node of nodes) {
      if (node.dataset?.slutSearchBlocked === 'true') continue;
      if (node.tagName === 'IFRAME' && fromCamProvider(node.getAttribute('src'))) {
        const overlay = node.closest(overlaySelector);
        hide(overlay && isOverlay(overlay) ? overlay : node);
      } else if (namedAsStreamChat(node) && isOverlay(node)) {
        // Only hide floating chat widgets; don't erase an ordinary site page.
        hide(node);
      } else if (visiblyStreamAndChat(node)) {
        hide(node);
      }
    }
  }
  let scheduled = false;
  function scheduleScan() {
    if (scheduled) return;
    scheduled = true;
    setTimeout(() => { scheduled = false; scan(); }, 80);
  }
  function start() {
    if (!document.documentElement) return;
    scan();
    new MutationObserver(scheduleScan).observe(document.documentElement, {subtree: true, childList: true});
  }
  if (document.documentElement) start();
  else document.addEventListener('DOMContentLoaded', start, {once: true});
})();
