/* Reports *direct* HTTP(S) video resources visible to the web view.
   Does not try to defeat DRM, stream protection, or site rate limits. */
(() => {
  if (window.__slutSearchMediaHook) return;
  window.__slutSearchMediaHook = true;
  let last = '';
  function report() {
    const active = [...document.querySelectorAll('video')].find(v => !v.paused && v.readyState > 0)
      || document.querySelector('video');
    let candidate = '';
    for (const raw of [active?.currentSrc, active?.src, active?.querySelector('source')?.src]) {
      if (!raw) continue;
      try {
        const url = new URL(raw, location.href);
        if (/^https?:$/.test(url.protocol) && /\.(mp4|m4v|mov)(?:$|[?#])/i.test(url.href)) {
          candidate = url.href; break;
        }
      } catch (_) {}
    }
    if (candidate === last) return;
    last = candidate;
    window.webkit?.messageHandlers?.slutSearchMedia?.postMessage({url: candidate});
  }
  document.addEventListener('play', report, true);
  document.addEventListener('loadedmetadata', report, true);
  document.addEventListener('loadstart', () => setTimeout(report, 80), true);
  new MutationObserver(() => setTimeout(report, 80)).observe(document.documentElement, {childList: true, subtree: true, attributes: true, attributeFilter: ["src"]});
  setInterval(report, 2000);
  report();
})();

/* Website navigation bridge: keep the native URL/title/Back state in sync
   when the site uses Blazor or another SPA router. */
(() => {
  if (window.__slutSearchNavigationHook) return;
  window.__slutSearchNavigationHook = true;
  let lastURL = '';
  let lastTitle = '';
  function reportNavigation() {
    if (location.href === lastURL && document.title === lastTitle) return;
    lastURL = location.href;
    lastTitle = document.title;
    window.webkit?.messageHandlers?.slutSearchNavigation?.postMessage({url:lastURL, title:lastTitle});
    dispatchEvent(new Event('slutsearch:navigation'));
  }
  for (const method of ['pushState', 'replaceState']) {
    const native = history[method];
    if (typeof native !== 'function') continue;
    history[method] = function(...args) {
      const result = native.apply(this, args);
      setTimeout(reportNavigation, 0);
      return result;
    };
  }
  addEventListener('popstate', reportNavigation);
  addEventListener('hashchange', reportNavigation);
  addEventListener('pageshow', reportNavigation);
  const title = document.querySelector('title');
  if (title) new MutationObserver(reportNavigation).observe(title, {childList:true,characterData:true,subtree:true});
  reportNavigation();
})();

/* SlutSearch 1.3: website-first context bridge.
 * Never changes the site's playlist/like/selection semantics and never downloads
 * preview thumbnails as originals. Native iOS asks for scan on an explicit tap.
 */
(() => {
  if (window.__slutSearchSiteBridge) return;
  window.__slutSearchSiteBridge = true;
  const message = (name, payload) => window.webkit?.messageHandlers?.[name]?.postMessage(payload);
  const isAllowed = (raw) => {
    try {
      const u = new URL(raw, location.href);
      return u.protocol === 'https:' && u.href;
    } catch (_) { return null; }
  };
  const classify = (url) => {
    try {
      const path = new URL(url).pathname;
      if (/\.(mp4|m4v|mov)$/i.test(path)) return 'video';
      if (/\.(jpe?g|png|heic)$/i.test(path)) return 'image';
    } catch (_) {}
    return null;
  };
  function pageKind() {
    const path = (location.pathname + location.hash).toLowerCase();
    // The listing of all playlists is not a playlist of media itself.
    if (/\/(?:playlists|playlist)\/.+/.test(path)) return 'playlist';
    if (/\/(?:posts|post|view)\/.+/.test(path)) return 'post';
    if (document.querySelector('video[src],video source[src]')) return 'post';
    return 'other';
  }
  function isSelected(el) {
    const node = el.closest('[aria-selected="true"],[aria-checked="true"],[data-selected="true"],.is-selected,.selected');
    if (node && node !== document.body && node !== document.documentElement) return true;
    const parent = el.closest('article,li,[role="listitem"],.card');
    return Boolean(parent?.querySelector('input[type="checkbox"]:checked,[role="checkbox"][aria-checked="true"]'));
  }
  window.slutSearchScanMedia = function() {
    const files = [], known = new Set();
    let truncated = false;
    const selectedCount = [...document.querySelectorAll('[aria-selected="true"],[aria-checked="true"],[data-selected="true"],input[type="checkbox"]:checked')]
      .filter(el => !!el.closest('article,li,[role="listitem"],.card')).length;
    function add(raw, element, title) {
      const url = isAllowed(raw);
      if (!url || !classify(url) || known.has(url)) return;
      if (files.length >= 100) { truncated = true; return; }
      known.add(url);
      files.push({ id: url, url, kind: classify(url), title: String(title || new URL(url).pathname.split('/').pop() || 'Медиафайл').slice(0,160), selected: isSelected(element) });
    }
    // The site's explicit download links and file links provide the most trustworthy URLs.
    for (const a of document.querySelectorAll('a[href]')) {
      const raw = a.getAttribute('href');
      if (a.closest('nav,header,footer,[role="navigation"]')) continue;
      if (raw && classify(isAllowed(raw))) add(raw, a, a.getAttribute('download') || a.title || a.textContent?.trim());
    }
    // Active player/source URLs, not poster images.
    for (const video of document.querySelectorAll('video')) {
      for (const raw of [video.currentSrc, video.getAttribute('src'), video.querySelector('source')?.getAttribute('src')]) {
        if (raw && classify(isAllowed(raw)) === 'video') add(raw, video, document.title);
      }
    }
    // Images inside the actual post viewer only. Grid images are generally resized previews.
    for (const img of document.querySelectorAll('[role="dialog"] img, [data-post-viewer] img, main article img')) {
      if (!img.complete || img.naturalWidth < 800 || img.naturalHeight < 600) continue;
      if (img.closest('a[href]') && !classify(isAllowed(img.closest('a[href]').getAttribute('href')))) continue;
      const raw = img.currentSrc || img.src;
      if (raw && classify(isAllowed(raw)) === 'image') add(raw, img, img.alt || document.title);
    }
    // Do not infer unseen pages, scrape APIs, or claim thumbnails are originals.
    const chosen = files.filter(f => f.selected);
    return { kind: pageKind(), files: chosen.length ? chosen : files, selectedCount, truncated };
  };
  let lastContext = '';
  function reportContext() {
    const kind = pageKind();
    if (kind === lastContext) return;
    lastContext = kind;
    message('slutSearchContext', {kind, url: location.href});
  }
  const watcher = new MutationObserver(() => { if (!window.__slutSearchContextTimer) {
    window.__slutSearchContextTimer = setTimeout(() => { window.__slutSearchContextTimer = null; reportContext(); }, 350);
  }});
  watcher.observe(document.documentElement, {childList: true, subtree: true});
  addEventListener('slutsearch:navigation', reportContext);
  addEventListener('popstate', reportContext);
  addEventListener('hashchange', reportContext);
  addEventListener('pageshow', reportContext);
  document.addEventListener('click', () => setTimeout(reportContext, 200), true);
  setInterval(reportContext, 2500);
  reportContext();
})();
