import Foundation
import WebKit
import Combine

struct DirectVideoScan {
    let urls: [URL]
    let truncated: Bool
}

enum SitePageKind: String { case other, playlist, post }

struct SiteMediaFile: Identifiable {
    let id: String
    let url: URL
    let kind: String
    let title: String
}

struct SiteMediaScan {
    let files: [SiteMediaFile]
    let selectedCount: Int
    let truncated: Bool
    static let empty = SiteMediaScan(files: [], selectedCount: 0, truncated: false)
}

/// WKUserContentController strongly holds message handlers: use a weak relay to avoid retaining BrowserSession forever.
private final class WeakMediaHandler: NSObject, WKScriptMessageHandler {
    weak var target: BrowserSession?
    init(target: BrowserSession) { self.target = target }
    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        target?.userContentController(userContentController, didReceive: message)
    }
}

final class BrowserSession: NSObject, ObservableObject, WKNavigationDelegate, WKUIDelegate, WKScriptMessageHandler, WKDownloadDelegate {
    @Published private(set) var currentURL: URL?
    @Published private(set) var currentVideoURL: URL?
    @Published private(set) var canGoBack = false
    @Published private(set) var canGoForward = false
    @Published private(set) var pageTitle = "SlutSearch <3"
    @Published private(set) var activeSearchQuery: String?
    @Published private(set) var activeFilter: MediaKind = .all
    @Published var notice: String?
    @Published private(set) var pageKind: SitePageKind = .other
    var onWebsiteFileDownloaded: ((URL, URL?) -> Void)?
    private var siteFileDestinations: [ObjectIdentifier: URL] = [:]
    @Published private(set) var blockLiveChat: Bool

    private static let liveChatHosts = [
        "chaturbate.com", "stripchat.com", "livejasmin.com", "bongacams.com",
        "myfreecams.com", "camsoda.com", "streamate.com", "chatango.com",
        "tawk.to", "crisp.chat", "tidiochat.com"
    ]

    let homeURL = URL(string: "https://rule34vault.com/")!
    private(set) var webView: WKWebView!
    private var wantedFilter: MediaKind = .all
    private var pendingFilter: MediaKind?

    override init() {
        blockLiveChat = UserDefaults.standard.object(forKey: "SlutSearch.BlockLiveChat") as? Bool ?? true
        super.init()
        let config = WKWebViewConfiguration()
        config.websiteDataStore = .default()
        config.allowsInlineMediaPlayback = true
        config.mediaTypesRequiringUserActionForPlayback = [.audio, .video]
        let uc = WKUserContentController()
        installScripts(in: uc)
        uc.add(WeakMediaHandler(target: self), name: "slutSearchMedia")
        uc.add(WeakMediaHandler(target: self), name: "slutSearchNavigation")
        uc.add(WeakMediaHandler(target: self), name: "slutSearchContext")
        config.userContentController = uc
        webView = WKWebView(frame: .zero, configuration: config)
        webView.navigationDelegate = self
        webView.uiDelegate = self
        webView.allowsBackForwardNavigationGestures = true
        webView.load(URLRequest(url: homeURL))
    }

    private func installScripts(in controller: WKUserContentController) {
        controller.removeAllUserScripts()
        if blockLiveChat,
           let path = Bundle.main.url(forResource: "PopupGuard", withExtension: "js"),
           let code = try? String(contentsOf: path, encoding: .utf8) {
            // Inject into embedded frames too: many livestream/chat promotions use iframes.
            controller.addUserScript(WKUserScript(source: code, injectionTime: .atDocumentStart, forMainFrameOnly: false))
        }
        if let path = Bundle.main.url(forResource: "WebHooks", withExtension: "js"),
           let code = try? String(contentsOf: path, encoding: .utf8) {
            controller.addUserScript(WKUserScript(source: code, injectionTime: .atDocumentEnd, forMainFrameOnly: true))
        }
    }

    func setLiveChatBlocking(_ enabled: Bool) {
        guard blockLiveChat != enabled else { return }
        blockLiveChat = enabled
        UserDefaults.standard.set(enabled, forKey: "SlutSearch.BlockLiveChat")
        installScripts(in: webView.configuration.userContentController)
        webView.reload()
    }

    private func isLiveChatHost(_ url: URL) -> Bool {
        let host = url.host?.lowercased() ?? ""
        return Self.liveChatHosts.contains { host == $0 || host.hasSuffix("." + $0) }
    }

    // Stop known cam/chat embeds and unsolicited external windows before they load.
    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction,
                 decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        if navigationAction.shouldPerformDownload {
            decisionHandler(.download)
            return
        }
        if blockLiveChat, let url = navigationAction.request.url, isLiveChatHost(url) {
            decisionHandler(.cancel)
            return
        }
        decisionHandler(.allow)
    }

    func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration,
                 for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
        // A user-tapped link that requests target=_blank must still work in an app with
        // one WebView. Unsolicited JS popups are discarded to avoid unwanted live chats.
        guard navigationAction.navigationType == .linkActivated,
              let url = navigationAction.request.url,
              ["https", "http"].contains(url.scheme?.lowercased() ?? "") else { return nil }
        if blockLiveChat && isLiveChatHost(url) { return nil }
        webView.load(URLRequest(url: url))
        return nil
    }

    // The website's own download button can use WebKit's authenticated download path.
    func webView(_ webView: WKWebView, navigationAction: WKNavigationAction, didBecome download: WKDownload) {
        download.delegate = self
    }

    func webView(_ webView: WKWebView, navigationResponse: WKNavigationResponse, didBecome download: WKDownload) {
        download.delegate = self
    }

    func download(_ download: WKDownload, decideDestinationUsing response: URLResponse,
                  suggestedFilename: String, completionHandler: @escaping (URL?) -> Void) {
        let ext = (suggestedFilename as NSString).pathExtension.lowercased()
        guard ["jpg", "jpeg", "png", "heic", "mp4", "mov", "m4v"].contains(ext) else {
            notice = "Сайт предложил неподдерживаемый формат: \(suggestedFilename)."
            completionHandler(nil)
            return
        }
        let folder = FileManager.default.temporaryDirectory.appendingPathComponent("SlutSearchWebsiteFiles", isDirectory: true)
        do {
            try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
            let target = folder.appendingPathComponent(UUID().uuidString).appendingPathExtension(ext)
            siteFileDestinations[ObjectIdentifier(download)] = target
            completionHandler(target)
        } catch {
            notice = "Не удалось подготовить загрузку: \(error.localizedDescription)"
            completionHandler(nil)
        }
    }

    func downloadDidFinish(_ download: WKDownload) {
        guard let url = siteFileDestinations.removeValue(forKey: ObjectIdentifier(download)) else { return }
        onWebsiteFileDownloaded?(url, download.originalRequest.url)
    }

    func download(_ download: WKDownload, didFailWithError error: Error, resumeData: Data?) {
        if let url = siteFileDestinations.removeValue(forKey: ObjectIdentifier(download)) {
            try? FileManager.default.removeItem(at: url)
        }
        notice = "Загрузка сайта не удалась: \(error.localizedDescription)"
    }

    deinit {
        webView?.configuration.userContentController.removeScriptMessageHandler(forName: "slutSearchMedia")
        webView?.configuration.userContentController.removeScriptMessageHandler(forName: "slutSearchNavigation")
        webView?.configuration.userContentController.removeScriptMessageHandler(forName: "slutSearchContext")
    }

    /// Site playlists are not local bookmark collections; load the actual site's section
    /// inside the same WKWebView / cookie store (not Safari or an unauthenticated window).
    func openSitePlaylists() {
        guard let playlistURL = URL(string: "/playlists", relativeTo: homeURL)?.absoluteURL else { return }
        navigate(to: playlistURL)
    }

    func home() {
        activeSearchQuery = nil
        activeFilter = .all
        navigate(to: homeURL)
    }
    func back() { if webView.canGoBack { webView.goBack() } }
    func forward() { if webView.canGoForward { webView.goForward() } }
    func refresh() { webView.reload() }
    func navigate(to url: URL, filter: MediaKind = .all, searchQuery: String? = nil) {
        guard ["https", "http"].contains(url.scheme?.lowercased() ?? "") else { return }
        activeSearchQuery = searchQuery
        activeFilter = filter
        wantedFilter = filter
        pendingFilter = filter == .all ? nil : filter
        currentVideoURL = nil
        webView.load(URLRequest(url: url))
    }

    func setFilter(_ media: MediaKind) {
        wantedFilter = media
        activeFilter = media
        let label = media.siteLabel
        let js = """
        (() => {const label=\(String(reflecting: label));const items=[...document.querySelectorAll('button,[role="radio"],label')];
        const exact=items.filter(e=>(e.textContent||'').trim().toLowerCase()===label.toLowerCase());
        const control=exact.find(e=>/media type/i.test(e.parentElement?.parentElement?.textContent||''))||exact[0];
        if(control){control.click();return true}return false})()
        """
        webView.evaluateJavaScript(js) { [weak self] result, error in
            guard let self = self else { return }
            if error != nil || (result as? Bool) != true {
                DispatchQueue.main.async { self.notice = "На этой странице переключатель типа медиа не найден. Фильтрация зависит от сайта." }
            }
        }
    }

    /// Reads the site's currently rendered media without replacing site playlists or selection.
    /// The site may only expose previews; in that case return no direct files rather than guessing.
    func scanSiteMedia(completion: @escaping (SiteMediaScan) -> Void) {
        webView.evaluateJavaScript("window.slutSearchScanMedia ? window.slutSearchScanMedia() : null") { value, _ in
            let data = value as? [String: Any] ?? [:]
            let raw = data["files"] as? [[String: Any]] ?? []
            let files = raw.compactMap { row -> SiteMediaFile? in
                guard let source = row["url"] as? String,
                      let url = URL(string: source), url.scheme?.lowercased() == "https",
                      let kind = row["kind"] as? String,
                      ["video", "image"].contains(kind) else { return nil }
                let title = row["title"] as? String ?? url.lastPathComponent
                return SiteMediaFile(id: source, url: url, kind: kind, title: title)
            }
            completion(SiteMediaScan(files: files, selectedCount: data["selectedCount"] as? Int ?? 0,
                                     truncated: data["truncated"] as? Bool ?? false))
        }
    }

    /// Enumerates direct file URLs on the currently rendered page only. Max 100.
    /// Never crawls the site, fetches private APIs, or attempts to defeat media protection.
    func discoverDirectVideos(completion: @escaping (DirectVideoScan) -> Void) {
        let js = """
        (() => {
          const found = [];
          const known = new Set();
          let truncated = false;
          const nodes = document.querySelectorAll('video[src],video source[src],a[href]');
          for (const node of nodes) {
            const raw = node.getAttribute('src') || node.getAttribute('href');
            if (!raw) continue;
            try {
              const url = new URL(raw, location.href);
              if (url.protocol !== 'https:' || !/\\.(mp4|m4v|mov)$/i.test(url.pathname)) continue;
              if (known.has(url.href)) continue;
              known.add(url.href);
              if (found.length === 100) { truncated = true; break; }
              found.push(url.href);
            } catch (_) {}
          }
          return { urls: found, truncated };
        })()
        """
        webView.evaluateJavaScript(js) { value, _ in
            let result = value as? [String: Any] ?? [:]
            let raw = result["urls"] as? [String] ?? []
            let urls = raw.compactMap(URL.init(string:)).filter { $0.scheme?.lowercased() == "https" }
            completion(DirectVideoScan(urls: urls, truncated: result["truncated"] as? Bool ?? false))
        }
    }

    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        DispatchQueue.main.async {
            self.currentURL = webView.url
            self.pageTitle = webView.title ?? "SlutSearch <3"
            self.canGoBack = webView.canGoBack
            self.canGoForward = webView.canGoForward
            self.currentVideoURL = nil
            if let pending = self.pendingFilter {
                self.pendingFilter = nil
                self.setFilter(pending)
            }
        }
    }

    func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
        DispatchQueue.main.async {
            self.currentVideoURL = nil
            self.pageKind = .other
        }
    }

    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
        DispatchQueue.main.async { self.notice = "Не удалось открыть страницу: \(error.localizedDescription)" }
    }

    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        guard let body = message.body as? [String: Any] else { return }
        if message.name == "slutSearchContext" {
            guard message.frameInfo.isMainFrame, let kind = body["kind"] as? String else { return }
            DispatchQueue.main.async { self.pageKind = SitePageKind(rawValue: kind) ?? .other }
            return
        }
        if message.name == "slutSearchNavigation" {
            // Client-side navigation (pushState/replaceState) does not call didFinish.
            // Keep bookmark and navigation controls tied to the actual URL.
            guard message.frameInfo.isMainFrame,
                  let raw = body["url"] as? String,
                  let url = URL(string: raw),
                  ["https", "http"].contains(url.scheme?.lowercased() ?? "") else { return }
            let title = body["title"] as? String
            DispatchQueue.main.async {
                self.currentURL = url
                if let title, !title.isEmpty { self.pageTitle = title }
                self.canGoBack = self.webView.canGoBack
                self.canGoForward = self.webView.canGoForward
            }
            return
        }
        guard message.name == "slutSearchMedia",
              let raw = body["url"] as? String else { return }
        let url = URL(string: raw)
        guard let url, ["http", "https"].contains(url.scheme?.lowercased() ?? "") else {
            DispatchQueue.main.async { self.currentVideoURL = nil }
            return
        }
        DispatchQueue.main.async { self.currentVideoURL = url }
    }

    func downloadCookies(completion: @escaping ([HTTPCookie]) -> Void) {
        webView.configuration.websiteDataStore.httpCookieStore.getAllCookies { completion($0) }
    }
}
