import SwiftUI

@main
struct SlutSearchApp: App {
    @StateObject private var browser = BrowserSession()
    @StateObject private var searches = SearchStore()
    @StateObject private var downloads = VideoDownloadManager()
    @StateObject private var collections = CollectionsStore()

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(browser)
                .environmentObject(searches)
                .environmentObject(downloads)
                .environmentObject(collections)
                .preferredColorScheme(.dark)
        }
    }
}
