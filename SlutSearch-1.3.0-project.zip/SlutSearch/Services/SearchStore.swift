import Foundation
import Combine

/// Search settings persist independently of the website's localStorage.
enum MediaKind: String, CaseIterable, Identifiable, Codable {
    case all = "Всё", images = "Изображения", videos = "Видео"
    var id: String { rawValue }
    var siteLabel: String {
        switch self {
        case .all: return "All"
        case .images: return "Images"
        case .videos: return "Videos"
        }
    }
}

struct SearchProfile: Identifiable, Codable, Equatable {
    var id: UUID = UUID()
    var name: String
    var query: String
    var mediaKind: MediaKind
}

final class SearchStore: ObservableObject {
    @Published var query = ""
    @Published var profileName = ""
    @Published var mediaKind: MediaKind = .all
    @Published private(set) var history: [String] = []
    @Published private(set) var profiles: [SearchProfile] = []

    private let historyKey = "SlutSearch.SearchHistory.v2"
    private let profileKey = "SlutSearch.SearchProfiles.v2"
    private let defaults = UserDefaults.standard

    init() {
        history = (try? JSONDecoder().decode([String].self, from: defaults.data(forKey: historyKey) ?? Data())) ?? []
        profiles = (try? JSONDecoder().decode([SearchProfile].self, from: defaults.data(forKey: profileKey) ?? Data())) ?? []
    }

    static func normalize(_ raw: String) -> String {
        raw.split(whereSeparator: \.isWhitespace).joined(separator: " ")
    }

    /// Uses the existing site's pipe-separated URL convention. No client-side tag cap.
    /// The website may still impose limits or change its routes.
    static func searchURL(for query: String, origin: URL) -> URL? {
        let tags = normalize(query).split(separator: " ")
        guard !tags.isEmpty else { return nil }
        let allowed = CharacterSet.urlPathAllowed.subtracting(CharacterSet(charactersIn: "|/?#%"))
        let path = tags.map { String($0).addingPercentEncoding(withAllowedCharacters: allowed) ?? "" }
            .joined(separator: "%7C")
        return URL(string: origin.absoluteString.trimmingCharacters(in: CharacterSet(charactersIn: "/")) + "/" + path)
    }

    @discardableResult
    func recordSearch() -> String? {
        let normalized = Self.normalize(query)
        guard !normalized.isEmpty else { return nil }
        query = normalized
        history.removeAll(where: { $0 == normalized })
        history.insert(normalized, at: 0)
        if history.count > 30 { history = Array(history.prefix(30)) }
        persistHistory()
        return normalized
    }

    func saveProfile() {
        let name = profileName.trimmingCharacters(in: .whitespacesAndNewlines)
        let normalized = Self.normalize(query)
        guard !name.isEmpty, !normalized.isEmpty else { return }
        if let idx = profiles.firstIndex(where: { $0.name.caseInsensitiveCompare(name) == .orderedSame }) {
            profiles[idx].query = normalized
            profiles[idx].mediaKind = mediaKind
        } else {
            profiles.append(SearchProfile(name: name, query: normalized, mediaKind: mediaKind))
        }
        persistProfiles()
    }

    func use(_ profile: SearchProfile) {
        query = profile.query
        mediaKind = profile.mediaKind
        profileName = profile.name
    }

    func delete(_ profile: SearchProfile) {
        profiles.removeAll(where: { $0.id == profile.id })
        persistProfiles()
    }

    func clearHistory() { history.removeAll(); persistHistory() }

    private func persistHistory() {
        defaults.set(try? JSONEncoder().encode(history), forKey: historyKey)
    }
    private func persistProfiles() {
        defaults.set(try? JSONEncoder().encode(profiles), forKey: profileKey)
    }
}
