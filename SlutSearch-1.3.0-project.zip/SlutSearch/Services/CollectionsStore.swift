import Foundation
import Combine

/// Local link collections. Media files are NOT copied or downloaded by this store.
struct SavedLink: Identifiable, Codable, Equatable {
    var id: UUID = UUID()
    var url: URL
    var title: String
    var savedAt: Date = Date()
}

struct LinkCollection: Identifiable, Codable, Equatable {
    var id: UUID = UUID()
    var name: String
    var links: [SavedLink] = []
}

final class CollectionsStore: ObservableObject {
    @Published private(set) var collections: [LinkCollection] = []
    private let storageKey = "SlutSearch.LinkCollections.v1"
    private let defaults: UserDefaults

    init(defaults: UserDefaults = .standard) {
        self.defaults = defaults
        if let saved = defaults.data(forKey: storageKey),
           let restored = try? JSONDecoder().decode([LinkCollection].self, from: saved) {
            collections = restored
        }
        if collections.isEmpty {
            collections = [LinkCollection(name: "Избранное")]
            persist()
        }
    }

    @discardableResult
    func create(_ name: String) -> UUID? {
        let trimmed = name.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty, trimmed.count <= 70 else { return nil }
        guard !collections.contains(where: { $0.name.caseInsensitiveCompare(trimmed) == .orderedSame }) else { return nil }
        let collection = LinkCollection(name: trimmed)
        collections.append(collection)
        persist()
        return collection.id
    }

    @discardableResult
    func save(_ url: URL, title: String, to collectionID: UUID? = nil) -> Bool {
        guard ["https", "http"].contains(url.scheme?.lowercased() ?? ""),
              let index = collections.firstIndex(where: { $0.id == (collectionID ?? collections[0].id) }) else { return false }
        guard !collections[index].links.contains(where: { $0.url == url }) else { return false }
        let label = title.trimmingCharacters(in: .whitespacesAndNewlines)
        collections[index].links.insert(SavedLink(url: url, title: label.isEmpty ? (url.host ?? "Страница") : label), at: 0)
        persist()
        return true
    }

    func remove(_ linkID: UUID, from collectionID: UUID) {
        guard let index = collections.firstIndex(where: { $0.id == collectionID }) else { return }
        collections[index].links.removeAll(where: { $0.id == linkID })
        persist()
    }

    func deleteCollection(_ id: UUID) {
        guard collections.count > 1 else { return }
        collections.removeAll(where: { $0.id == id })
        persist()
    }

    func contains(_ url: URL) -> Bool {
        collections.contains(where: { $0.links.contains(where: { $0.url == url }) })
    }

    private func persist() {
        defaults.set(try? JSONEncoder().encode(collections), forKey: storageKey)
    }
}
