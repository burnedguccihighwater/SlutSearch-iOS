from pathlib import Path
from playwright.sync_api import sync_playwright
root = Path(__file__).resolve().parents[1]
js = (root / 'SlutSearch/Web/WebHooks.js').read_text()
with sync_playwright() as pw:
    browser = pw.chromium.launch(headless=True, executable_path='/usr/bin/chromium', args=['--no-sandbox'])
    page = browser.new_page()
    context = []
    page.expose_function('logCtx', lambda x: context.append(x))
    fixture = '''<!doctype html><html><head><title>Playlist</title></head><body>
    <nav><a href="https://static.example.com/logo.png">Logo</a></nav>
    <main><article aria-selected="true"><a download="clip.mp4" href="https://media.example.com/one.mp4">Video</a></article>
    <article aria-selected="false"><a href="https://media.example.com/two.jpg">Image original</a></article>
    <article><img src="https://media.example.com/preview.jpg" width="300" height="300"></article></main>
    </body></html>'''
    page.set_content(fixture)
    page.evaluate('window.webkit={messageHandlers:{slutSearchMedia:{postMessage:()=>{}},slutSearchNavigation:{postMessage:()=>{}},slutSearchContext:{postMessage:x=>window.logCtx(x)}}}')
    page.evaluate(js)
    page.evaluate('history.pushState({}, "", "#/playlists/123")')
    page.wait_for_timeout(550)
    found = page.evaluate('window.slutSearchScanMedia()')
    assert found['kind'] == 'playlist', found
    assert len(found['files']) == 1, found
    assert found['files'][0]['url'].endswith('/one.mp4'), found
    assert found['selectedCount'] == 1, found
    assert context[-1]['kind'] == 'playlist', context
    # After deselecting, the explicit file URLs (not thumbnails/site logo) become selectable.
    page.evaluate("document.querySelector('article').setAttribute('aria-selected','false')")
    all_items = page.evaluate('window.slutSearchScanMedia()')
    assert len(all_items['files']) == 2, all_items
    assert all('.jpg' not in x['url'] or x['url'].endswith('two.jpg') for x in all_items['files']), all_items
    page.evaluate('history.pushState({}, "", "#/playlists")')
    page.wait_for_timeout(500)
    assert page.evaluate('window.slutSearchScanMedia().kind') == 'other'
    print('PASS: playlist context, selection, direct media URLs, order, skip preview and nav icons')
    browser.close()
