from playwright.sync_api import sync_playwright
from pathlib import Path
script = (Path(__file__).resolve().parents[1] / 'SlutSearch/Web/WebHooks.js').read_text()
with sync_playwright() as pw:
    b = pw.chromium.launch(headless=True, executable_path='/usr/bin/chromium', args=['--no-sandbox'])
    p = b.new_page()
    messages = []
    p.expose_function('recordFromWebkit', lambda payload: messages.append(payload))
    p.set_content('''<html><body><video id="v"><source src="https://media.example.org/clip.mp4?token=x" type="video/mp4"></video></body></html>''')
    p.evaluate("window.webkit={messageHandlers:{slutSearchMedia:{postMessage:(x)=>window.recordFromWebkit(x)}}}")
    p.evaluate(script)
    p.wait_for_timeout(350)
    assert messages[-1]['url'].startswith('https://media.example.org/clip.mp4'), messages
    p.locator('#v source').evaluate('(el)=>el.src="https://media.example.org/chunk.m3u8"')
    p.evaluate('document.querySelector("video").load()')
    p.wait_for_timeout(350)
    assert messages[-1]['url'] == '', messages
    p.locator('#v source').evaluate('(el)=>el.src="blob:https://media.example.org/abc"')
    p.evaluate('document.querySelector("video").load()')
    p.wait_for_timeout(350)
    assert messages[-1]['url'] == ''
    p.locator('#v source').evaluate('(el)=>el.src="https://media.example.org/new.m4v"')
    p.evaluate('document.querySelector("video").load()')
    p.wait_for_timeout(350)
    assert messages[-1]['url'].endswith('/new.m4v'), messages
    print('PASS: direct video detection and dynamic source changes')
    b.close()
