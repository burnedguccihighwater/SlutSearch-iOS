from pathlib import Path
import re
from playwright.sync_api import sync_playwright

source = (Path(__file__).resolve().parents[1] / 'SlutSearch/Web/BrowserSession.swift').read_text()
match = re.search(r'func discoverDirectVideos\(.*?let js = """\n(.*?)\n        """', source, re.S)
assert match, 'Missing discoverDirectVideos JS'
script = match.group(1).replace(r'\\.', r'\.')  # Swift string literal escaping -> JS regex

with sync_playwright() as pw:
    browser = pw.chromium.launch(headless=True, executable_path='/usr/bin/chromium', args=['--no-sandbox'])
    page = browser.new_page()
    page.set_content('''<video src="https://media.example.com/one.mp4?x=1"></video>
    <a href="https://media.example.com/two.MOV">two</a>
    <a href="https://media.example.com/one.mp4?x=1">duplicate</a>
    <a href="https://media.example.com/playlist.m3u8">HLS</a>
    <a href="blob:https://media.example.com/abc">blob</a>
    <a href="http://media.example.com/insecure.mp4">http</a>
    <a href="https://media.example.com/third.mp4.pdf">not video</a>''')
    result = page.evaluate(script)
    assert result['urls'] == ['https://media.example.com/one.mp4?x=1', 'https://media.example.com/two.MOV'], result
    assert result['truncated'] is False
    page.set_content(''.join(f'<a href="https://media.example.com/{i}.mp4">x</a>' for i in range(105)))
    result = page.evaluate(script)
    assert len(result['urls']) == 100 and result['truncated'] is True, result
    print('PASS: deduplicates direct https mp4/mov, excludes HLS/blob/http, caps at 100')
    browser.close()
