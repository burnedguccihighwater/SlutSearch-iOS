from pathlib import Path
import json, plistlib
root = Path(__file__).resolve().parents[1]
asset = root / 'SlutSearch/Assets.xcassets/AppIcon.appiconset'
settings = json.loads((asset/'Contents.json').read_text())
for item in settings['images']:
    assert (asset/item['filename']).is_file(), item
pl = plistlib.loads((root/'SlutSearch/Info.plist').read_bytes())
assert pl['CFBundleDisplayName'] == 'SlutSearch <3'
assert pl['CFBundleShortVersionString'] == '1.3.0'
assert pl['CFBundleVersion'] == '12'
assert 'NSPhotoLibraryAddUsageDescription' in pl
project = (root/'SlutSearch.xcodeproj/project.pbxproj').read_text()
assert 'com.FPR.2bea62c' in project
assert 'MARKETING_VERSION = 1.3.0;' in project
for path in (root/'SlutSearch').rglob('*.swift'):
    assert path.name in project, path
for needle in ['CollectionsStore.swift', 'CollectionsView.swift', 'SpecialFeaturesView.swift']:
    assert needle in project
assert (root/'SlutSearch/Web/WebHooks.js').is_file()
assert (root/'SlutSearch/Web/PopupGuard.js').is_file()
assert 'PopupGuard.js' in project
assert len(list((root/'SlutSearch').rglob('*.swift'))) == 11
print('PASS: all source files in Xcode target, icons, version, entitlement descriptions and bundle ID')

assert 'AppSection' not in (root/'SlutSearch/UI/RootView.swift').read_text()
assert 'slutSearchNavigation' in (root/'SlutSearch/Web/BrowserSession.swift').read_text()

assert 'BrowserView()' in (root/'SlutSearch/UI/RootView.swift').read_text()
assert 'AppSection' not in (root/'SlutSearch/UI/RootView.swift').read_text()
assert 'window.slutSearchScanMedia' in (root/'SlutSearch/Web/WebHooks.js').read_text()
assert 'saveWebsiteFile' in (root/'SlutSearch/Services/VideoDownloadManager.swift').read_text()
assert 'WKDownloadDelegate' in (root/'SlutSearch/Web/BrowserSession.swift').read_text()
print('PASS: unified browser UI, website media bridge and native WebKit download path')
