from pathlib import Path
from playwright.sync_api import sync_playwright
root = Path(__file__).resolve().parents[1]
hooks = (root / 'SlutSearch/Web/WebHooks.js').read_text()
guard = (root / 'SlutSearch/Web/PopupGuard.js').read_text()
with sync_playwright() as pw:
    browser = pw.chromium.launch(headless=True, executable_path='/usr/bin/chromium', args=['--no-sandbox'])
    page = browser.new_page()
    nav = []
    page.expose_function('recordNav', lambda value: nav.append(value))
    page.set_content('''<!doctype html><html><head><title>R34 Vault</title></head>
    <body><a id="playlist" href="/playlists" target="_blank">Playlists</a>
    <video id="ordinary" controls></video>
    <div id="floating" class="live-chat" style="position:fixed;bottom:20px;right:20px;width:250px;height:260px"><iframe src="https://chaturbate.com/embed"></iframe></div>
    <div id="sign-in" role="dialog" style="position:fixed;left:20px;top:20px;width:250px;height:180px">Sign in to account</div>
    </body></html>''')
    page.evaluate('window.webkit={messageHandlers:{slutSearchNavigation:{postMessage:x=>window.recordNav(x)},slutSearchMedia:{postMessage:()=>{}}}}')
    page.evaluate(hooks)
    page.evaluate('history.pushState({},"","#playlists")')
    page.wait_for_timeout(200)
    assert nav and nav[-1]['url'].endswith('#playlists'), nav
    page.evaluate('history.replaceState({},"","#my-playlists")')
    page.wait_for_timeout(200)
    assert nav[-1]['url'].endswith('#my-playlists'), nav
    page.evaluate('window.open = (url) => { window.__lastOpen = url; return null; }')
    page.evaluate(guard)
    page.wait_for_timeout(250)
    assert page.locator('#ordinary').is_visible(), 'ordinary video hidden'
    assert page.locator('#sign-in').is_visible(), 'legitimate dialog hidden'
    assert not page.locator('#floating').is_visible(), 'livestream overlay not hidden'
    page.evaluate("window.open('https://example.org/legitimate-link')")
    assert page.evaluate('window.__lastOpen') == 'https://example.org/legitimate-link', 'normal external link swallowed'
    page.evaluate("window.__lastOpen = '';window.open('https://chaturbate.com/stream')")
    assert page.evaluate('window.__lastOpen') == '', 'cam popup passed'
    print('PASS: SPA navigation, normal video/sign-in preserved, intrusive stream hidden, site links preserved')
    browser.close()
