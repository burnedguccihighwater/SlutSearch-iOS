# SlutSearch 1.3.0 — iPhone QA plan

1. Install unsigned-built IPA after signing it normally for the device; confirm launch and persistence of account sign-in.
2. Open website playlists, likes, profile: site navigation should be unchanged, no duplicate bottom tabs or floating panels over controls.
3. Tap a playlist's publication and a standalone post: contextual Download button should appear only on relevant pages; on playlist listing without files it should not appear.
4. If the site uses long press to select several posts, mark two and tap Download. Verify selected post files appear when represented by the DOM. If selection is internal JS state, note the incompatibility for adapter work.
5. Confirm visible JPEG, PNG, HEIC, MP4/MOV/M4V direct URLs are listed. No grid previews, avatars, icons or unsupported HLS/blob streams should be misreported as original downloads.
6. Confirm selected files are saved to iOS Photos, correct permission prompt, file type, orientation and playback. Check no duplicates and order-preserving queue.
7. Test the site's own Save/Download control. Verify WKDownload path, cookie authorization and Photos completion if the site uses standard web downloads.
8. Test empty/partial playlist and pagination: UI must state that only currently exposed originals are downloaded; NEVER claim whole playlist completed.
9. Test the usual site All / Images / Videos controls, extended search, history and search profiles.
10. Test playback, account login popup/new tab, and block-live-chat option; regular video must keep working.
11. Verify 320, 375, 390 and 430 pt screens, plus portrait/landscape for overlapping controls.
12. Verify background/foreground, offline states and denied Photos permission; no fake success toast.
