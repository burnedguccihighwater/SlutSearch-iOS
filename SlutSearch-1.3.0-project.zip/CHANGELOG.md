# SlutSearch <3 — Changelog

## 1.3.0 (Build 12) — Site Integration
- Browser-first UI: removed duplicate site tabs.
- Compact contextual download action for active post/playlist pages.
- Native bridge for selected currently rendered media and direct original links.
- Save images/videos to Photos, retain site order, manual multi-selection confirmation.
- WKDownloadDelegate for site-initiated downloads using existing WebKit session.
- Download progress sheet only when needed, no manual MP4 URL field.
- Existing advanced tag search, popup suppression, web cookies and native app identity kept.
- Known limitation: cannot guarantee all playlist pages or assets exposed only through site APIs.

## 1.2.2 (Build 11)
- Playlist link and SPA navigation fixes, live chat suppression.
