#!/usr/bin/env bash
# Reproducible, truly compiled unsigned iOS IPA. Requires macOS + Xcode/iOS SDK.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
if ! command -v xcodebuild >/dev/null 2>&1; then
  echo 'ERROR: Xcode/xcodebuild is missing. Run on macOS with Xcode or GitHub Actions macOS.' >&2
  exit 2
fi
if ! xcrun --sdk iphoneos --show-sdk-path >/dev/null 2>&1; then
  echo 'ERROR: iPhoneOS SDK not found. Select an Xcode installation with iOS SDK.' >&2
  exit 2
fi
python3 Tests/verify_package.py
xcrun swiftc -frontend -parse SlutSearch/Services/*.swift SlutSearch/UI/*.swift SlutSearch/Web/*.swift SlutSearch/SlutSearchApp.swift
if command -v node >/dev/null 2>&1; then
  node --check SlutSearch/Web/WebHooks.js
else
  echo 'NOTICE: node is not installed; skipping optional JavaScript syntax check.'
fi
mkdir -p .build dist
xcodebuild -project SlutSearch.xcodeproj \
  -scheme SlutSearch \
  -configuration Release \
  -destination 'generic/platform=iOS' \
  -sdk iphoneos \
  -derivedDataPath "$ROOT/.build/DerivedData" \
  CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO CODE_SIGN_IDENTITY='' \
  build 2>&1 | tee "$ROOT/.build/xcodebuild.log"
APP="$ROOT/.build/DerivedData/Build/Products/Release-iphoneos/SlutSearch.app"
if [[ ! -f "$APP/SlutSearch" ]]; then
  echo 'ERROR: SlutSearch.app or its executable was not produced.' >&2
  exit 1
fi
if ! lipo -archs "$APP/SlutSearch" | tr ' ' '\n' | grep -qx 'arm64'; then
  echo 'ERROR: the executable does not contain the arm64 iPhone architecture.' >&2
  exit 1
fi
python3 - "$APP/Info.plist" <<'PY'
from pathlib import Path
import plistlib, sys
info = plistlib.loads(Path(sys.argv[1]).read_bytes())
required = {'CFBundleIdentifier': 'com.FPR.2bea62c', 'CFBundleShortVersionString': '1.3.0',
            'CFBundleVersion': '12', 'CFBundleDisplayName': 'SlutSearch <3'}
for k, v in required.items():
    assert info.get(k) == v, f'{k}: {info.get(k)!r} != {v!r}'
assert 'NSPhotoLibraryAddUsageDescription' in info
print('PASS: compiled app metadata, version and Photos permission')
PY
STAGING="$ROOT/.build/ipa-staging"
rm -rf "$STAGING"
mkdir -p "$STAGING/Payload"
ditto "$APP" "$STAGING/Payload/SlutSearch.app"
IPA="$ROOT/dist/SlutSearch-iOS-1.3.0-unsigned.ipa"
rm -f "$IPA"
(cd "$STAGING" && zip -qry "$IPA" Payload)
unzip -tq "$IPA"
file "$APP/SlutSearch"
echo "SUCCESS: $IPA"
ls -lh "$IPA"
shasum -a 256 "$IPA" > "$IPA.sha256"
echo 'This IPA is UNSIGNED. Sign it with your own valid iOS signing certificate before installing.'
