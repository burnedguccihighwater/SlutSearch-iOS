# Changelog

## [1.2.1] - 2026-11-09 (Native source, Build 9)
- Fixed navigation layout: four equal-width tabs and separate browser action row.
- Added results-level All / Images / Videos picker (site-dependent).
- Added local link collections, bookmark Quick Save, and removal of saved entries.
- Added visible-page direct-file scanner for the "Download entire playlist" entry under Special Features, with a preview and explicit confirmation.
- Added deduplication, safe batch queueing (up to 100 per scan) and persisted download status history.
- Strengthened download request validation and redirected Cookie header handling.
- Added screen concealment on inactive/background scene phase (partial privacy feature).
- Preserved bundle ID and search profiles/history functionality.

**Not shipped as a compiled iOS app.**

## [1.2.0] - 2026-11-09 (Native source, Build 8)
- Initial separate Browser, Search, Downloads native tabs.
- Direct MP4/MOV/M4V video download to iOS Photos using URLSession and Photos.
- Search tags, filters, history and saved profiles.

## [1.1.1] - 2026-11-09 (patched IPA, Build 7)
- Compact responsive search overlay in the compiled WebView wrapper.
