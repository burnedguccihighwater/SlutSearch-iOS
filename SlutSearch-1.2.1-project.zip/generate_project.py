from pathlib import Path
import hashlib,json,io
from PIL import Image,ImageDraw,ImageFont
ROOT=Path(__file__).resolve().parent
ASSETS=ROOT/'SlutSearch/Assets.xcassets/AppIcon.appiconset'
ASSETS.mkdir(parents=True,exist_ok=True)
S=1024
im=Image.new('RGB',(S,S))
d=ImageDraw.Draw(im)
for y in range(S):
 t=y/(S-1)
 d.line((0,y,S,y),fill=(int(10+14*t),int(10+6*t),int(19+29*t)))
d.rounded_rectangle((90,90,934,934),radius=200,outline=(154,111,236),width=25)
font='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
f=ImageFont.truetype(font,490)
d.text((259,185),'S',font=f,fill=(249,245,255))
d.ellipse((624,680,702,754),fill=(245,115,171))
d.ellipse((682,680,760,754),fill=(245,115,171))
d.polygon([(623,725),(760,725),(694,813)],fill=(245,115,171))
entries=[]
for idiom, sizes, scales in [('iphone',[20,29,40,60],[2,3]),('ipad',[20,29,40,76,83.5],[1,2])]:
 if idiom=='ipad': continue
 for s in sizes:
  for sc in scales:
   if s==60 and sc==2 or s==60 and sc==3 or s!=60:
    px=int(s*sc)
    fn=f'icon-{px}.png'
    im.resize((px,px),Image.Resampling.LANCZOS).save(ASSETS/fn,optimize=True)
    entries.append({'filename':fn,'idiom':idiom,'size':f'{s}x{s}','scale':f'{sc}x'})
im.save(ASSETS/'icon-1024.png',optimize=True)
entries.append({'filename':'icon-1024.png','idiom':'ios-marketing','size':'1024x1024','scale':'1x'})
(ASSETS/'Contents.json').write_text(json.dumps({'images':entries,'info':{'version':1,'author':'xcode'}},indent=2))
(ROOT/'SlutSearch/Assets.xcassets/Contents.json').write_text(json.dumps({'info':{'version':1,'author':'xcode'}}))

# Standard explicit PBX project: no external generator required to open it.
def ID(k):return hashlib.sha1(('slutsearch:'+k).encode()).hexdigest()[:24].upper()
def q(s):return '"'+s.replace('\\','\\\\').replace('"','\\"')+'"'
objects=[]
def obj(name,isa,fields):
 objects.append((name,'{\n\t\t\tisa = '+isa+';\n'+''.join('\t\t\t'+k+' = '+v+';\n' for k,v in fields.items())+'\t\t}'))
def arr(xs):return '(\n'+''.join('\t\t\t\t'+x+',\n' for x in xs)+'\t\t\t)'
app='SlutSearch.app'
src_files=['SlutSearchApp.swift','Services/SearchStore.swift','Services/VideoDownloadManager.swift','Services/CollectionsStore.swift','Web/BrowserSession.swift','UI/RootView.swift','UI/BrowserView.swift','UI/SearchView.swift','UI/DownloadsView.swift','UI/CollectionsView.swift','UI/SpecialFeaturesView.swift']
refs={}
for f in src_files:
 name='SlutSearch/'+f
 refs[name]=ID('file:'+name)
 obj(refs[name],'PBXFileReference',{'lastKnownFileType':'sourcecode.swift','path':q(f.split('/')[-1]),'sourceTree':'"<group>"'})
refs['WebHooks.js']=ID('file:WebHooks.js')
obj(refs['WebHooks.js'],'PBXFileReference',{'lastKnownFileType':'sourcecode.javascript','path':q('WebHooks.js'),'sourceTree':'"<group>"'})
refs['Assets.xcassets']=ID('file:assets')
obj(refs['Assets.xcassets'],'PBXFileReference',{'lastKnownFileType':'folder.assetcatalog','path':'Assets.xcassets','sourceTree':'"<group>"'})
refs['Info.plist']=ID('file:plist')
obj(refs['Info.plist'],'PBXFileReference',{'lastKnownFileType':'text.plist.xml','path':'Info.plist','sourceTree':'"<group>"'})
appref=ID('product')
obj(appref,'PBXFileReference',{'explicitFileType':'wrapper.application','includeInIndex':'0','path':q(app),'sourceTree':'BUILT_PRODUCTS_DIR'})
files_build={}
for key in src_files+['WebHooks.js','Assets.xcassets']:
 k='SlutSearch/'+key if key in src_files else key
 f=refs[k];bid=ID('build:'+key);files_build[key]=bid
 obj(bid,'PBXBuildFile',{'fileRef':f+' /* '+key.split('/')[-1]+' */'})
groups={x:ID('group:'+x) for x in ['root','main','services','web','ui','products']}
obj(groups['services'],'PBXGroup',{'children':arr([refs['SlutSearch/Services/'+f] for f in ['SearchStore.swift','VideoDownloadManager.swift','CollectionsStore.swift']]),'path':'Services','sourceTree':'"<group>"'})
obj(groups['web'],'PBXGroup',{'children':arr([refs['SlutSearch/Web/BrowserSession.swift'],refs['WebHooks.js']]),'path':'Web','sourceTree':'"<group>"'})
obj(groups['ui'],'PBXGroup',{'children':arr([refs['SlutSearch/UI/'+f] for f in ['RootView.swift','BrowserView.swift','SearchView.swift','DownloadsView.swift','CollectionsView.swift','SpecialFeaturesView.swift']]),'path':'UI','sourceTree':'"<group>"'})
obj(groups['main'],'PBXGroup',{'children':arr([refs['SlutSearch/SlutSearchApp.swift'],groups['services'],groups['web'],groups['ui'],refs['Assets.xcassets'],refs['Info.plist']]),'path':'SlutSearch','sourceTree':'"<group>"'})
obj(groups['products'],'PBXGroup',{'children':arr([appref]),'name':'Products','sourceTree':'"<group>"'})
obj(groups['root'],'PBXGroup',{'children':arr([groups['main'],groups['products']]),'sourceTree':'"<group>"'})
sources=ID('sources');res=ID('resources');frameworks=ID('frameworks')
obj(sources,'PBXSourcesBuildPhase',{'buildActionMask':'2147483647','files':arr([files_build[f] for f in src_files]),'runOnlyForDeploymentPostprocessing':'0'})
obj(res,'PBXResourcesBuildPhase',{'buildActionMask':'2147483647','files':arr([files_build[f] for f in ['WebHooks.js','Assets.xcassets']]),'runOnlyForDeploymentPostprocessing':'0'})
obj(frameworks,'PBXFrameworksBuildPhase',{'buildActionMask':'2147483647','files':'()','runOnlyForDeploymentPostprocessing':'0'})
configs={}
for level in ['project','target']:
 for mode in ['Debug','Release']:
  name=ID('cfg:'+level+mode);configs[level+mode]=name
  if level=='project':
   settings={'ALWAYS_SEARCH_USER_PATHS':'NO','CLANG_ENABLE_MODULES':'YES','IPHONEOS_DEPLOYMENT_TARGET':'15.0','SDKROOT':'iphoneos','SWIFT_VERSION':'5.0','SWIFT_OPTIMIZATION_LEVEL':q('-Onone' if mode=='Debug' else '-O'),'TARGETED_DEVICE_FAMILY':q('1')}
  else:
   settings={'ASSETCATALOG_COMPILER_APPICON_NAME':'AppIcon','CODE_SIGN_STYLE':'Automatic','CURRENT_PROJECT_VERSION':'9','GENERATE_INFOPLIST_FILE':'NO','INFOPLIST_FILE':q('SlutSearch/Info.plist'),'IPHONEOS_DEPLOYMENT_TARGET':'15.0','MARKETING_VERSION':'1.2.1','PRODUCT_BUNDLE_IDENTIFIER':'com.FPR.2bea62c','PRODUCT_NAME':q('SlutSearch'),'SDKROOT':'iphoneos','SWIFT_VERSION':'5.0','SUPPORTS_MACCATALYST':'NO','TARGETED_DEVICE_FAMILY':q('1')}
  obj(name,'XCBuildConfiguration',{'buildSettings':'{\n'+''.join('\t\t\t\t'+k+' = '+v+';\n' for k,v in settings.items())+'\t\t\t}','name':mode})
for level in ['project','target']:
 key=ID('cfgList:'+level);configs['list'+level]=key
 obj(key,'XCConfigurationList',{'buildConfigurations':arr([configs[level+x] for x in ['Debug','Release']]),'defaultConfigurationIsVisible':'0','defaultConfigurationName':'Release'})
target=ID('target')
obj(target,'PBXNativeTarget',{'buildConfigurationList':configs['listtarget'],'buildPhases':arr([sources,frameworks,res]),'buildRules':'()','dependencies':'()','name':'SlutSearch','productName':'SlutSearch','productReference':appref,'productType':q('com.apple.product-type.application')})
project=ID('project')
obj(project,'PBXProject',{'attributes':'{ LastUpgradeCheck = 1640; TargetAttributes = { '+target+' = { CreatedOnToolsVersion = 16.4; ProvisioningStyle = Automatic; }; }; }','buildConfigurationList':configs['listproject'],'compatibilityVersion':q('Xcode 14.0'),'developmentRegion':'ru','hasScannedForEncodings':'0','knownRegions':'(ru, en, Base)','mainGroup':groups['root'],'productRefGroup':groups['products'],'projectDirPath':q(''),'projectRoot':q(''),'targets':arr([target])})
text='// !$*UTF8*$!\n{\n\tarchiveVersion = 1;\n\tclasses = {};\n\tobjectVersion = 60;\n\tobjects = {\n'
for name,body in objects:text+='\t\t'+name+' = '+body+';\n'
text+='\t};\n\trootObject = '+project+';\n}\n'
(ROOT/'SlutSearch.xcodeproj/project.pbxproj').write_text(text)
print('Project',ROOT,'with',len(objects),'objects and',len(entries),'icon catalog variants')
