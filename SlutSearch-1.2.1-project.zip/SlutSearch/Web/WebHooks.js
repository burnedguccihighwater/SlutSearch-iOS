/* Reports *direct* HTTP(S) video resources visible to the web view.
   Does not try to defeat DRM, stream protection, or site rate limits. */
(() => {
  if (window.__slutSearchMediaHook) return;
  window.__slutSearchMediaHook = true;
  let last = '';
  function report() {
    const active = [...document.querySelectorAll('video')].find(v => !v.paused && v.readyState > 0)
      || document.querySelector('video');
    let candidate = '';
    for (const raw of [active?.currentSrc, active?.src, active?.querySelector('source')?.src]) {
      if (!raw) continue;
      try {
        const url = new URL(raw, location.href);
        if (/^https?:$/.test(url.protocol) && /\.(mp4|m4v|mov)(?:$|[?#])/i.test(url.href)) {
          candidate = url.href; break;
        }
      } catch (_) {}
    }
    if (candidate === last) return;
    last = candidate;
    window.webkit?.messageHandlers?.slutSearchMedia?.postMessage({url: candidate});
  }
  document.addEventListener('play', report, true);
  document.addEventListener('loadedmetadata', report, true);
  document.addEventListener('loadstart', () => setTimeout(report, 80), true);
  new MutationObserver(() => setTimeout(report, 80)).observe(document.documentElement, {childList: true, subtree: true, attributes: true, attributeFilter: ["src"]});
  setInterval(report, 2000);
  report();
})();
