import Foundation
import WebKit
import Combine

struct DirectVideoScan {
    let urls: [URL]
    let truncated: Bool
}

/// WKUserContentController strongly holds message handlers: use a weak relay to avoid retaining BrowserSession forever.
private final class WeakMediaHandler: NSObject, WKScriptMessageHandler {
    weak var target: BrowserSession?
    init(target: BrowserSession) { self.target = target }
    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        target?.userContentController(userContentController, didReceive: message)
    }
}

final class BrowserSession: NSObject, ObservableObject, WKNavigationDelegate, WKScriptMessageHandler {
    @Published private(set) var currentURL: URL?
    @Published private(set) var currentVideoURL: URL?
    @Published private(set) var canGoBack = false
    @Published private(set) var canGoForward = false
    @Published private(set) var pageTitle = "SlutSearch <3"
    @Published private(set) var activeSearchQuery: String?
    @Published private(set) var activeFilter: MediaKind = .all
    @Published var notice: String?

    let homeURL = URL(string: "https://rule34vault.com/")!
    private(set) var webView: WKWebView!
    private var wantedFilter: MediaKind = .all
    private var pendingFilter: MediaKind?

    override init() {
        super.init()
        let config = WKWebViewConfiguration()
        config.websiteDataStore = .default()
        config.allowsInlineMediaPlayback = true
        config.mediaTypesRequiringUserActionForPlayback = [.audio, .video]
        let uc = WKUserContentController()
        if let scriptURL = Bundle.main.url(forResource: "WebHooks", withExtension: "js"),
           let source = try? String(contentsOf: scriptURL, encoding: .utf8) {
            uc.addUserScript(WKUserScript(source: source, injectionTime: .atDocumentEnd, forMainFrameOnly: true))
        }
        uc.add(WeakMediaHandler(target: self), name: "slutSearchMedia")
        config.userContentController = uc
        webView = WKWebView(frame: .zero, configuration: config)
        webView.navigationDelegate = self
        webView.allowsBackForwardNavigationGestures = true
        webView.load(URLRequest(url: homeURL))
    }

    deinit { webView?.configuration.userContentController.removeScriptMessageHandler(forName: "slutSearchMedia") }

    func home() {
        activeSearchQuery = nil
        activeFilter = .all
        navigate(to: homeURL)
    }
    func back() { if webView.canGoBack { webView.goBack() } }
    func forward() { if webView.canGoForward { webView.goForward() } }
    func refresh() { webView.reload() }
    func navigate(to url: URL, filter: MediaKind = .all, searchQuery: String? = nil) {
        guard ["https", "http"].contains(url.scheme?.lowercased() ?? "") else { return }
        activeSearchQuery = searchQuery
        activeFilter = filter
        wantedFilter = filter
        pendingFilter = filter == .all ? nil : filter
        currentVideoURL = nil
        webView.load(URLRequest(url: url))
    }

    func setFilter(_ media: MediaKind) {
        wantedFilter = media
        activeFilter = media
        let label = media.siteLabel
        let js = """
        (() => {const label=\(String(reflecting: label));const items=[...document.querySelectorAll('button,[role="radio"],label')];
        const exact=items.filter(e=>(e.textContent||'').trim().toLowerCase()===label.toLowerCase());
        const control=exact.find(e=>/media type/i.test(e.parentElement?.parentElement?.textContent||''))||exact[0];
        if(control){control.click();return true}return false})()
        """
        webView.evaluateJavaScript(js) { [weak self] result, error in
            guard let self = self else { return }
            if error != nil || (result as? Bool) != true {
                DispatchQueue.main.async { self.notice = "На этой странице переключатель типа медиа не найден. Фильтрация зависит от сайта." }
            }
        }
    }

    /// Enumerates direct file URLs on the currently rendered page only. Max 100.
    /// Never crawls the site, fetches private APIs, or attempts to defeat media protection.
    func discoverDirectVideos(completion: @escaping (DirectVideoScan) -> Void) {
        let js = """
        (() => {
          const found = [];
          const known = new Set();
          let truncated = false;
          const nodes = document.querySelectorAll('video[src],video source[src],a[href]');
          for (const node of nodes) {
            const raw = node.getAttribute('src') || node.getAttribute('href');
            if (!raw) continue;
            try {
              const url = new URL(raw, location.href);
              if (url.protocol !== 'https:' || !/\\.(mp4|m4v|mov)$/i.test(url.pathname)) continue;
              if (known.has(url.href)) continue;
              known.add(url.href);
              if (found.length === 100) { truncated = true; break; }
              found.push(url.href);
            } catch (_) {}
          }
          return { urls: found, truncated };
        })()
        """
        webView.evaluateJavaScript(js) { value, _ in
            let result = value as? [String: Any] ?? [:]
            let raw = result["urls"] as? [String] ?? []
            let urls = raw.compactMap(URL.init(string:)).filter { $0.scheme?.lowercased() == "https" }
            completion(DirectVideoScan(urls: urls, truncated: result["truncated"] as? Bool ?? false))
        }
    }

    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        DispatchQueue.main.async {
            self.currentURL = webView.url
            self.pageTitle = webView.title ?? "SlutSearch <3"
            self.canGoBack = webView.canGoBack
            self.canGoForward = webView.canGoForward
            self.currentVideoURL = nil
            if let pending = self.pendingFilter {
                self.pendingFilter = nil
                self.setFilter(pending)
            }
        }
    }

    func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
        DispatchQueue.main.async { self.currentVideoURL = nil }
    }

    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
        DispatchQueue.main.async { self.notice = "Не удалось открыть страницу: \(error.localizedDescription)" }
    }

    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        guard message.name == "slutSearchMedia",
              let body = message.body as? [String: Any],
              let raw = body["url"] as? String else { return }
        let url = URL(string: raw)
        guard let url, ["http", "https"].contains(url.scheme?.lowercased() ?? "") else {
            DispatchQueue.main.async { self.currentVideoURL = nil }
            return
        }
        DispatchQueue.main.async { self.currentVideoURL = url }
    }

    func downloadCookies(completion: @escaping ([HTTPCookie]) -> Void) {
        webView.configuration.websiteDataStore.httpCookieStore.getAllCookies { completion($0) }
    }
}
