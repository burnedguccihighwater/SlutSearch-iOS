import SwiftUI
import WebKit

private struct EmbeddedWebView: UIViewRepresentable {
    let session: BrowserSession
    func makeUIView(context: Context) -> WKWebView { session.webView }
    func updateUIView(_ uiView: WKWebView, context: Context) {}
}

struct BrowserView: View {
    @EnvironmentObject private var browser: BrowserSession
    @EnvironmentObject private var downloads: VideoDownloadManager
    @EnvironmentObject private var collections: CollectionsStore
    @State private var showingTools = false
    var onShowDownloads: () -> Void
    var onShowCollections: () -> Void

    var body: some View {
        VStack(spacing: 0) {
            VStack(spacing: 4) {
                HStack(spacing: 8) {
                    Text("SlutSearch <3")
                        .font(.headline).lineLimit(1).minimumScaleFactor(0.7)
                    Spacer(minLength: 2)
                    Button { savePage() } label: {
                        Image(systemName: "bookmark.fill")
                            .frame(width: 36, height: 36)
                    }.accessibilityLabel("Быстро сохранить страницу")
                    Button { showingTools = true } label: {
                        Image(systemName: "ellipsis.circle")
                            .frame(width: 36, height: 36)
                    }.accessibilityLabel("Особые возможности")
                }
                HStack(spacing: 10) {
                    navButton("chevron.left", "Назад", disabled: !browser.canGoBack) { browser.back() }
                    navButton("chevron.right", "Вперёд", disabled: !browser.canGoForward) { browser.forward() }
                    navButton("house", "Домой") { browser.home() }
                    navButton("arrow.clockwise", "Обновить") { browser.refresh() }
                }
                if browser.activeSearchQuery != nil {
                    Picker("Результаты", selection: Binding(
                        get: { browser.activeFilter },
                        set: { browser.setFilter($0) }
                    )) {
                        ForEach(MediaKind.allCases) { kind in Text(kind.rawValue).tag(kind) }
                    }
                    .pickerStyle(.segmented)
                    .accessibilityLabel("Фильтр результатов поиска")
                    .padding(.top, 5)
                }
            }
            .tint(.white)
            .padding(.horizontal, 12)
            .padding(.vertical, 6)
            .background(Color(red: 0.10, green: 0.08, blue: 0.15))

            EmbeddedWebView(session: browser)
                .frame(maxWidth: .infinity, maxHeight: .infinity)

            if let url = browser.currentVideoURL {
                HStack(spacing: 8) {
                    Image(systemName: "film")
                    Text("Видео найдено").font(.caption).lineLimit(1)
                    Spacer(minLength: 4)
                    Button {
                        browser.downloadCookies { cookies in
                            DispatchQueue.main.async {
                                downloads.add(url, cookies: cookies)
                                onShowDownloads()
                            }
                        }
                    } label: { Label("В Фото", systemImage: "square.and.arrow.down") }
                        .buttonStyle(.borderedProminent)
                        .tint(.purple)
                }
                .font(.subheadline)
                .padding(.horizontal, 12).padding(.vertical, 8)
                .background(Color(red: 0.12, green: 0.09, blue: 0.18))
            }
        }
        .sheet(isPresented: $showingTools) { SpecialFeaturesView() }
    }

    private func navButton(_ symbol: String, _ label: String, disabled: Bool = false, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Image(systemName: symbol)
                .font(.system(size: 17, weight: .medium))
                .frame(maxWidth: .infinity, minHeight: 38)
                .background(Color.white.opacity(0.07))
                .clipShape(RoundedRectangle(cornerRadius: 9))
        }
        .disabled(disabled)
        .accessibilityLabel(label)
    }

    private func savePage() {
        guard let url = browser.currentURL else {
            browser.notice = "Сначала открой страницу."
            return
        }
        if collections.save(url, title: browser.pageTitle) {
            onShowCollections()
        } else {
            browser.notice = "Эта страница уже сохранена в Избранное или ссылку нельзя сохранить."
        }
    }
}
