import SwiftUI

private enum AppSection: Int, CaseIterable {
    case browser, search, collections, downloads
    var name: String {
        switch self {
        case .browser: return "Обзор"
        case .search: return "Поиск"
        case .collections: return "Коллекции"
        case .downloads: return "Загрузки"
        }
    }
    var icon: String {
        switch self {
        case .browser: return "globe"
        case .search: return "magnifyingglass"
        case .collections: return "bookmark"
        case .downloads: return "arrow.down.circle"
        }
    }
}

struct RootView: View {
    @EnvironmentObject private var browser: BrowserSession
    @EnvironmentObject private var downloads: VideoDownloadManager
    @Environment(\.scenePhase) private var scenePhase
    @State private var tab: AppSection = .browser

    var body: some View {
        ZStack {
            Color(red: 0.055, green: 0.044, blue: 0.080).ignoresSafeArea()
            switch tab {
            case .browser:
                BrowserView(onShowDownloads: { tab = .downloads }, onShowCollections: { tab = .collections })
            case .search:
                SearchView(onSearch: { tab = .browser })
            case .collections:
                CollectionsView(onOpenLink: { tab = .browser })
            case .downloads:
                DownloadsView()
            }
        }
        .safeAreaInset(edge: .bottom, spacing: 0) {
            HStack(spacing: 4) {
                ForEach(AppSection.allCases, id: \.rawValue) { section in
                    Button { tab = section } label: {
                        VStack(spacing: 4) {
                            Image(systemName: section.icon).font(.system(size: 19, weight: .medium))
                            Text(section.name)
                                .font(.system(size: 10, weight: .semibold))
                                .lineLimit(1).minimumScaleFactor(0.75)
                        }
                        .foregroundColor(tab == section ? .white : .gray)
                        .frame(maxWidth: .infinity, minHeight: 56)
                        .contentShape(Rectangle())
                        .background(tab == section ? Color.purple.opacity(0.30) : Color.clear)
                        .clipShape(RoundedRectangle(cornerRadius: 12))
                    }
                    .buttonStyle(.plain)
                    .accessibilityLabel(section.name)
                }
            }
            .padding(.horizontal, 10)
            .padding(.top, 7)
            .padding(.bottom, 5)
            .background(Color(red: 0.10, green: 0.08, blue: 0.15))
        }
        // Prevent content from appearing in the app switcher snapshot. Not a Face ID lock.
        .overlay {
            if scenePhase != .active {
                Color(red: 0.055, green: 0.044, blue: 0.080)
                    .ignoresSafeArea()
                    .overlay(Image(systemName: "eye.slash.fill").font(.largeTitle).foregroundColor(.gray))
                    .accessibilityLabel("Предпросмотр скрыт")
            }
        }
        .alert("SlutSearch", isPresented: Binding(
            get: { browser.notice != nil || downloads.notice != nil },
            set: { if !$0 { browser.notice = nil; downloads.notice = nil } }
        )) {
            Button("Понятно", role: .cancel) { browser.notice = nil; downloads.notice = nil }
        } message: {
            Text(browser.notice ?? downloads.notice ?? "")
        }
    }
}
