import Foundation
import Combine
import Photos

/// Downloads direct HTTPS video files and saves them to the system Photos library.
enum DownloadStatus: String, Codable {
    case queued = "В очереди"
    case downloading = "Загрузка"
    case saving = "Сохранение в Фото"
    case completed = "Сохранено в Фото"
    case failed = "Ошибка"
    case cancelled = "Отменено"
}

struct VideoDownload: Identifiable, Codable {
    let id: UUID
    let url: URL
    let title: String
    var progress: Double = 0
    var status: DownloadStatus = .queued
    var error: String?
}

final class VideoDownloadManager: NSObject, ObservableObject, URLSessionDownloadDelegate {
    @Published private(set) var items: [VideoDownload] = []
    @Published var notice: String?

    private let storageKey = "SlutSearch.DownloadHistory.v1"
    private lazy var session: URLSession = {
        let configuration = URLSessionConfiguration.default
        configuration.waitsForConnectivity = true
        configuration.httpShouldSetCookies = false
        configuration.httpCookieStorage = nil
        configuration.timeoutIntervalForRequest = 60
        configuration.timeoutIntervalForResource = 600
        return URLSession(configuration: configuration, delegate: self, delegateQueue: nil)
    }()

    private var taskToID: [Int: UUID] = [:]
    private var runningTasks: [UUID: URLSessionDownloadTask] = [:]
    private var cookiesByID: [UUID: [HTTPCookie]] = [:]
    private let maxConcurrent = 2
    private let maxBatch = 100

    override init() {
        super.init()
        if let data = UserDefaults.standard.data(forKey: storageKey),
           let stored = try? JSONDecoder().decode([VideoDownload].self, from: data) {
            // URLSessionConfiguration.default does not restore old tasks after process termination.
            items = stored.map { item in
                var copy = item
                if [.queued, .downloading, .saving].contains(copy.status) {
                    copy.status = .failed
                    copy.error = "Приложение было закрыто. Нажми «Повторить», чтобы начать заново."
                }
                return copy
            }
            persist()
        }
    }

    @discardableResult
    func add(_ url: URL, cookies: [HTTPCookie] = []) -> Bool {
        guard isSupportedDirectVideoURL(url) else {
            notice = "Нужна прямая HTTPS-ссылка на MP4, MOV или M4V."
            return false
        }
        guard !items.contains(where: { $0.url == url && [.queued, .downloading, .saving, .completed].contains($0.status) }) else {
            notice = "Это видео уже находится в очереди или было сохранено."
            return false
        }
        let filename = url.lastPathComponent.isEmpty ? "Видео" : url.lastPathComponent
        let item = VideoDownload(id: UUID(), url: url, title: filename)
        items.insert(item, at: 0)
        cookiesByID[item.id] = cookies
        persist()
        pump()
        return true
    }

    func addBatch(_ urls: [URL], cookies: [HTTPCookie] = []) {
        let unique = Array(Set(urls)).sorted { $0.absoluteString < $1.absoluteString }
        let valid = unique.filter(isSupportedDirectVideoURL)
        var added = 0
        for url in valid.prefix(maxBatch) {
            if items.contains(where: { $0.url == url && [.queued, .downloading, .saving, .completed].contains($0.status) }) {
                continue
            }
            let title = url.lastPathComponent.isEmpty ? "Видео" : url.lastPathComponent
            let item = VideoDownload(id: UUID(), url: url, title: title)
            items.append(item)
            cookiesByID[item.id] = cookies
            added += 1
        }
        persist()
        pump()
        notice = "Добавлено в очередь: \(added). Пропущено: \(urls.count - added)."
    }

    func cancel(_ id: UUID) {
        guard items.contains(where: { $0.id == id && [.queued, .downloading].contains($0.status) }) else { return }
        if let task = runningTasks.removeValue(forKey: id) {
            taskToID.removeValue(forKey: task.taskIdentifier)
            task.cancel()
        }
        cookiesByID.removeValue(forKey: id)
        mutate(id) { $0.status = .cancelled }
        pump()
    }

    func retry(_ id: UUID) {
        guard let idx = items.firstIndex(where: { $0.id == id }),
              [.failed, .cancelled].contains(items[idx].status) else { return }
        items[idx].status = .queued
        items[idx].progress = 0
        items[idx].error = nil
        persist()
        pump()
    }

    func clearFinished() {
        let removedIDs = items.filter { [.completed, .cancelled, .failed].contains($0.status) }.map(\.id)
        for id in removedIDs { cookiesByID.removeValue(forKey: id) }
        items.removeAll { [.completed, .cancelled, .failed].contains($0.status) }
        persist()
    }

    private func isSupportedDirectVideoURL(_ url: URL) -> Bool {
        url.scheme?.lowercased() == "https" && ["mp4", "mov", "m4v"].contains(url.pathExtension.lowercased())
    }

    private func persist() {
        // Retain only metadata/history, never cookies or downloaded video bytes.
        UserDefaults.standard.set(try? JSONEncoder().encode(Array(items.prefix(500))), forKey: storageKey)
    }

    private func mutate(_ id: UUID, _ action: (inout VideoDownload) -> Void) {
        guard let idx = items.firstIndex(where: { $0.id == id }) else { return }
        action(&items[idx])
        persist()
    }

    private func pump() {
        while runningTasks.count < maxConcurrent,
              let next = items.first(where: { $0.status == .queued }) {
            var request = URLRequest(url: next.url)
            let allowed = (cookiesByID[next.id] ?? []).filter { cookie in
                let host = next.url.host?.lowercased() ?? ""
                let domain = cookie.domain.lowercased().trimmingCharacters(in: CharacterSet(charactersIn: "."))
                guard host == domain || host.hasSuffix("." + domain) else { return false }
                guard !cookie.isSecure || next.url.scheme == "https" else { return false }
                return next.url.path.hasPrefix(cookie.path) && (cookie.expiresDate ?? .distantFuture) > Date()
            }
            if !allowed.isEmpty {
                for (key, value) in HTTPCookie.requestHeaderFields(with: allowed) {
                    request.setValue(value, forHTTPHeaderField: key)
                }
            }
            let task = session.downloadTask(with: request)
            taskToID[task.taskIdentifier] = next.id
            runningTasks[next.id] = task
            mutate(next.id) { $0.status = .downloading }
            task.resume()
        }
    }

    func urlSession(_ session: URLSession, task: URLSessionTask,
                    willPerformHTTPRedirection response: HTTPURLResponse,
                    newRequest request: URLRequest,
                    completionHandler: @escaping (URLRequest?) -> Void) {
        // Prevent leaking cookies to downgraded HTTP URLs.
        guard request.url?.scheme?.lowercased() == "https" else {
            completionHandler(nil)
            return
        }
        var safeRequest = request
        if task.originalRequest?.url?.host?.lowercased() != request.url?.host?.lowercased() {
            safeRequest.setValue(nil, forHTTPHeaderField: "Cookie")
        }
        completionHandler(safeRequest)
    }

    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask,
                    didWriteData bytesWritten: Int64, totalBytesWritten: Int64,
                    totalBytesExpectedToWrite: Int64) {
        guard totalBytesExpectedToWrite > 0 else { return }
        let fraction = min(1, Double(totalBytesWritten) / Double(totalBytesExpectedToWrite))
        DispatchQueue.main.async { [weak self] in
            guard let self = self,
                  let id = self.taskToID[downloadTask.taskIdentifier],
                  let idx = self.items.firstIndex(where: { $0.id == id }) else { return }
            self.items[idx].progress = fraction
        }
    }

    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask,
                    didFinishDownloadingTo location: URL) {
        let response = downloadTask.response as? HTTPURLResponse
        let status = response?.statusCode ?? 0
        let mime = response?.mimeType?.lowercased() ?? ""
        let urlExt = downloadTask.originalRequest?.url?.pathExtension.lowercased() ?? ""
        let nameExt = (response?.suggestedFilename as NSString?)?.pathExtension.lowercased() ?? ""
        let acceptableMime = ["video/mp4", "video/quicktime", "video/x-m4v", "application/octet-stream", "binary/octet-stream"].contains(mime)
        guard (200..<300).contains(status), acceptableMime,
              ["mp4", "mov", "m4v"].contains(urlExt) || ["mp4", "mov", "m4v"].contains(nameExt) else {
            DispatchQueue.main.async { [weak self] in
                self?.finishError(downloadTask.taskIdentifier, "Получен неподдерживаемый ответ (HTTP \(status), \(mime)).")
            }
            return
        }
        let ext = mime == "video/quicktime" ? "mov" : (["mp4", "mov", "m4v"].contains(nameExt) ? nameExt : urlExt)
        let folder = FileManager.default.temporaryDirectory.appendingPathComponent("SlutSearchVideos", isDirectory: true)
        do {
            try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
            let destination = folder.appendingPathComponent(UUID().uuidString).appendingPathExtension(ext)
            try FileManager.default.moveItem(at: location, to: destination)
            DispatchQueue.main.async { [weak self] in self?.finishDownload(downloadTask.taskIdentifier, destination: destination) }
        } catch {
            DispatchQueue.main.async { [weak self] in self?.finishError(downloadTask.taskIdentifier, error.localizedDescription) }
        }
    }

    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        guard let error = error else { return }
        DispatchQueue.main.async { [weak self] in
            self?.finishError(task.taskIdentifier, error.localizedDescription)
        }
    }

    private func releaseTask(_ taskID: Int) -> UUID? {
        guard let id = taskToID.removeValue(forKey: taskID) else { return nil }
        runningTasks.removeValue(forKey: id)
        return id
    }

    private func finishError(_ taskID: Int, _ description: String) {
        guard let id = releaseTask(taskID) else { return }
        mutate(id) { $0.status = .failed; $0.error = description }
        pump()
    }

    private func finishDownload(_ taskID: Int, destination: URL) {
        guard let id = releaseTask(taskID) else {
            try? FileManager.default.removeItem(at: destination)
            return
        }
        mutate(id) { $0.status = .saving; $0.progress = 1 }
        pump()
        PHPhotoLibrary.requestAuthorization(for: .addOnly) { [weak self] access in
            guard access == .authorized || access == .limited else {
                DispatchQueue.main.async {
                    self?.mutate(id) { $0.status = .failed; $0.error = "Нет разрешения на сохранение в Фото. Проверь настройки iOS." }
                    try? FileManager.default.removeItem(at: destination)
                }
                return
            }
            PHPhotoLibrary.shared().performChanges({
                PHAssetChangeRequest.creationRequestForAssetFromVideo(atFileURL: destination)
            }, completionHandler: { [weak self] success, error in
                DispatchQueue.main.async {
                    self?.mutate(id) { item in
                        item.status = success ? .completed : .failed
                        item.error = success ? nil : (error?.localizedDescription ?? "Не удалось сохранить видео в Фото.")
                    }
                    if success { self?.cookiesByID.removeValue(forKey: id) }
                    try? FileManager.default.removeItem(at: destination)
                }
            })
        }
    }
}
