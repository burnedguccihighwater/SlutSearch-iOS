# iPhone QA plan (requires Xcode and device)

- [ ] Compile project in Xcode with iOS SDK and resolve any actual compile/typecheck issues.
- [ ] Sign/build/run on iPhone; verify fresh install and update from old bundle ID without unexpected data loss.
- [ ] In portrait at 320, 375, 390, 430 pt: check four bottom tabs, header rows, search picker and keyboard; nothing overlaps.
- [ ] Test landscape orientation with large Dynamic Type.
- [ ] Search tags separated by spaces; verify returned results (server may enforce a limit).
- [ ] Choose All, Images, Videos **after** search. Check real website filter applies correctly, not just UI state.
- [ ] Save and reopen a bookmarked page; restart app and confirm collection persistence.
- [ ] Create/delete extra collections; test duplicate URL handling.
- [ ] Test direct video HTTPS MP4 on device and Photos Add Only permission grant/refusal.
- [ ] Test two simultaneous downloads, third queued, cancel and retry, HTTP 403/404 and MIME mismatch.
- [ ] Check downloads from site using WKWebView cookies and media on a different domain.
- [ ] On a playlist page, scan and compare actual video count; if paginated/streamed, explain that not all can be downloaded.
- [ ] Test duplicate links, more than 100 links, different file extensions and invalid URL errors.
- [ ] Restart app mid-download: state should be interrupted with retry; do not imply automatic resumability.
- [ ] Check that app-switcher preview is obscured on inactive/background (device-dependent).
- [ ] Confirm localization of all button labels and VoiceOver targets.
